function AddCertifyInternalProcessOnStageChange()
{
	formContext.getControl("sbagcbd_bpf").setVisible(true);
	var bpfValue = formContext.getAttribute("sbagcbd_bpf").getValue();
	formContext.getControl("sbagcbd_bpf").setVisible(false);
	if(bpfValue == null)
	{
		// if the value of "sbagcbd_bpf" is null, then ensure we are on the default BPF
		// var bpfName = formContext.data.process.getInstanceName();
		//alert(bpfName);
		// if(bpfName != "Certify Internal Process")
		// {
			// reset it to the default BPF.
			formContext.data.process.getProcessInstances(function (instances) {
				Object.keys(instances).forEach(function (item) {
					if(instances[item].ProcessInstanceName == "Certify Internal Process")
					{
						//alert(instances[item].ProcessInstanceName);						
						formContext.data.process.setActiveProcessInstance(instances[item].ProcessInstanceID);
					}
				});					
			});
		// }
		// only set this onChange functions if we are in the default BPF
		formContext.data.process.addOnPreStageChange(CertifyInternalProcessOnStageChange);
		formContext.data.process.addOnStageChange(NavigateToCases);

	}
	else
	{
		// someone has indicated they want to start a different BPF, so load that BPF
		var bpfName = formContext.data.process.getInstanceName();
		//alert(bpfName);
		if(bpfName != bpfValue[0].name)
			formContext.data.process.setActiveProcess(bpfValue[0].id);
		if(bpfName == "Certify BPF Proposed Decert")
		{
			var activeStage = formContext.data.process.getActiveStage();
			//alert(activeStage[0].id);
			// move to Process stage if on the first stage
			// if(activeStage.getId() == "1eb204ca-82af-49fa-9d49-c9b086b86dcd")
			// {
				// // set the stage to "Process - Propose Decert"
				// //formContext.data.process.setActiveStage("a833dc59-0bd0-42ef-922c-2711bac4851b");
				// formContext.data.process.moveNext();
			// }
		}
	}
}




function CertifyInternalProcessOnStageChange(executionContext)
{	
	var bpfValue = formContext.getAttribute("sbagcbd_bpf").getValue();
	if(bpfValue == null)
	{
		// only do this if we are in the default BPF
		// Check for all checkboxes
		var stage = formContext.getAttribute("sbagcbd_currentstage").getValue();
		var alertStrings = { confirmButtonLabel: "Yes", text: "You must answer YES to all checklist items before continuing!", title: "Answer YES to all checklist items" };
		//var alertStrings = { confirmButtonLabel: "Yes", text: "This is an alert.", title: "Sample title" };	
		var alertOptions = { height: 200, width: 450 };
		var confirmStrings = {text: "Are you sure you want to change the application's stage?", title: "Change Application Stage" };
		var confirmOptions = {height: 200, width: 450 };
		var errorOptions = { message: "You must answer YES to all checklist items before continuing!" };
		var activeStage = formContext.data.process.getActiveStage();
		var selectedStage = formContext.data.process.getSelectedStage();
		debugger;
		var openReferrals = checkForOpenReferrals();
	// if(!openReferrals)
	// {
		switch(selectedStage.getName().toLowerCase())
		{	
			case "draft":
				if(activeStage.getName().toLowerCase() == "process" || activeStage.getName().toLowerCase() == "supervisor review" || activeStage.getName().toLowerCase() == "pd review" )
				{
					if (confirm("You can't go to a stage prior to the Process stage!"))
					{		
						executionContext.getEventArgs().preventDefault();
					}
					else
					{		
						executionContext.getEventArgs().preventDefault();
					}
				}
				else if(executionContext.getEventArgs().getDirection() == "Previous" || checkDraft())
				{
					debugger;
					if (confirm("Are you sure you want to change the application's stage?"))
					{		
						ShowHideChecklistFields(executionContext);
						
					}
					else
					{		
						executionContext.getEventArgs().preventDefault();
					}
				}	
				else
				{ 
					formContext.ui.setFormNotification("You must answer YES to all checklist items before continuing!", "ERROR", "1");
					if (confirm("You must answer YES to all checklist items before continuing!"))
					{		
						executionContext.getEventArgs().preventDefault(); 					
					}
					else
					{		
						executionContext.getEventArgs().preventDefault();
					}
				}
				break;
			case "pre-screen":
		// if((activeStage.getName().toLowerCase() == "process" || activeStage.getName().toLowerCase() == "supervisor review" || activeStage.getName().toLowerCase() == "pd review" )
			// && executionContext.getEventArgs().getDirection() == "Previous")
				// {
					// if (confirm("You can't go to a stage prior to the Process stage!"))
					// {		
						// executionContext.getEventArgs().preventDefault();
					// }
					// else
					// {		
						// executionContext.getEventArgs().preventDefault();
					// }
				// }
				if(activeStage.getName().toLowerCase() == "process" || activeStage.getName().toLowerCase() == "supervisor review" || activeStage.getName().toLowerCase() == "pd review" )
				{
					if (confirm("You can't go to a stage prior to the Process stage!"))
					{		
						executionContext.getEventArgs().preventDefault();
					}
					else
					{		
						executionContext.getEventArgs().preventDefault();
					}
				}			
				else if(executionContext.getEventArgs().getDirection() == "Previous")
				{
					debugger;
					if (confirm("You can't go to a stage prior to the Pre-Screen stage!"))
					{		
						executionContext.getEventArgs().preventDefault();
					}
					else
					{		
						executionContext.getEventArgs().preventDefault();
					}
				}	
				else if(checkPrescreen())
				{
					debugger;
					if (confirm("Are you sure you want to change the application's stage?"))
					{		
						ShowHideChecklistFields(executionContext);
						
					}
					else
					{		
						executionContext.getEventArgs().preventDefault();
					}
				}			
				else
				{ 
					formContext.ui.setFormNotification("You must answer YES to all checklist items before continuing!", "ERROR", "1");
					if (confirm("You must answer YES to all checklist items before continuing!"))
					{		
						executionContext.getEventArgs().preventDefault(); 					
					}
					else
					{		
						executionContext.getEventArgs().preventDefault();
					}
				}
				break;
			case "screen":
				// if((activeStage.getName().toLowerCase() == "process" || activeStage.getName().toLowerCase() == "supervisor review" || activeStage.getName().toLowerCase() == "pd review" )
					// && executionContext.getEventArgs().getDirection() == "Previous")
						// {
							// if (confirm("You can't go to a stage prior to the Process stage!"))
							// {		
								// executionContext.getEventArgs().preventDefault();
							// }
							// else
							// {		
								// executionContext.getEventArgs().preventDefault();
							// }
						// }
				if(activeStage.getName().toLowerCase() == "process" || activeStage.getName().toLowerCase() == "supervisor review" || activeStage.getName().toLowerCase() == "pd review" )
				{
					if (confirm("You can't go to a stage prior to the Process stage!"))
					{		
						executionContext.getEventArgs().preventDefault();
					}
					else
					{		
						executionContext.getEventArgs().preventDefault();
					}
				}				
				else if(executionContext.getEventArgs().getDirection() == "Previous")
				{
					if (confirm("Are you sure you want to change the application's stage?"))
					{		
						ShowHideChecklistFields(executionContext);
					}
					else
					{		
						executionContext.getEventArgs().preventDefault();
					}			
				}
				else if(checkScreen())
				{
					debugger;
					if (confirm("Are you sure you want to change the application's stage?"))
					{		
						ShowHideChecklistFields(executionContext);
						
					}
					else
					{		
						executionContext.getEventArgs().preventDefault();
					}
				}	
				else
				{ 
					formContext.ui.setFormNotification("You must answer YES to all checklist items before continuing!", "ERROR", "1");
					if (confirm("You must answer YES to all checklist items before continuing!"))
					{		
						executionContext.getEventArgs().preventDefault(); 					
					}
					else
					{		
						executionContext.getEventArgs().preventDefault();
					}
				}
				break;		
			case "process":
				// if(executionContext.getEventArgs().getDirection() == "Previous")
				// {
					// if (confirm("You can't go to a stage prior to the Process stage!"))
					// {		
						// executionContext.getEventArgs().preventDefault();
					// }
					// else
					// {		
						// executionContext.getEventArgs().preventDefault();
					// }			
				// }		
				// else 
				if(executionContext.getEventArgs().getDirection() == "Previous" || checkProcess())
				{
					debugger;
					if (confirm("Are you sure you want to change the application's stage?"))
					{		
						ShowHideChecklistFields(executionContext);
							
					}
					else
					{		
						executionContext.getEventArgs().preventDefault();
					}
				}	
				else
				{ 
					formContext.ui.setFormNotification("You must answer YES to all checklist items before continuing!", "ERROR", "1");
					if (confirm("You must answer YES to all checklist items before continuing!"))
					{		
						executionContext.getEventArgs().preventDefault(); 					
					}
					else
					{		
						executionContext.getEventArgs().preventDefault();
					}
				}		
				break;
			case "supervisor review":
				if(executionContext.getEventArgs().getDirection() == "Previous" || checkSupervisor())
				{
					debugger;
					if (confirm("Are you sure you want to change the application's stage?"))
					{		
						ShowHideChecklistFields(executionContext);
						
					}
					else
					{		
						executionContext.getEventArgs().preventDefault();
					}
				}	
				else
				{ 
					formContext.ui.setFormNotification("You must answer YES to all checklist items before continuing!", "ERROR", "1");
					if (confirm("You must answer YES to all checklist items before continuing!"))
					{		
						executionContext.getEventArgs().preventDefault(); 					
					}
					else
					{		
						executionContext.getEventArgs().preventDefault();
					}
				}
			case "pd review":
				if(executionContext.getEventArgs().getDirection() == "Previous" || checkPD())
				{
					debugger;
					if (confirm("Are you sure you want to change the application's stage?"))
					{		
							ShowHideChecklistFields(executionContext);
					
					}
					else
					{		
						executionContext.getEventArgs().preventDefault();
					}
				}	
				else
				{ 
					formContext.ui.setFormNotification("You must answer YES to all checklist items before continuing!", "ERROR", "1");
					if (confirm("You must answer YES to all checklist items before continuing!"))
					{		
						executionContext.getEventArgs().preventDefault(); 					
					}
					else
					{		
						executionContext.getEventArgs().preventDefault();
					}
				}		
				break;
		}
	}
	// }
	// else
	// {
		// if (confirm("You can't change the stage when there is an open referral!"))
		// {		
			// executionContext.getEventArgs().preventDefault(); 					
		// }
		// else
		// {		
			// executionContext.getEventArgs().preventDefault();
		// }
	// }
}

function NavigateToCases(executionContext)
{
	var pageInput = {
    pageType: "entitylist",
    entityName: "incident"
	};
	Xrm.Navigation.navigateTo(pageInput).then(
		function success() {
		},
		function error() {
		}
	);
}

function ShowHideChecklistFields(executionContext)
{
	try
	{
		debugger;
		var bpfValue = formContext.getAttribute("sbagcbd_bpf").getValue();
		if(bpfValue == null)
		{
			// only do this if we are in the default BPF
			//var stage = formContext.getAttribute("sbagcbd_currentstage").getValue();
			var stage = formContext.data.process.getActiveStage();
			var selectedState = formContext.data.process.getSelectedStage();
			switch(stage.getName().toLowerCase())
			{
				case "draft":
					disablePreScreenFields();
					disableScreenFields();			
					disableProcessFields();
					disableSupervisorFields();
					disablePDFields();
					
					control = formContext.getControl("header_process_sbagcbd_draftcompletedon"); if (control) control.setVisible(true);
					break;
				case "pre-screen":
					control = formContext.getControl("header_process_sbagcbd_draftcompletedon"); if (control) control.setDisabled(true);
					disableScreenFields();			
					disableProcessFields();
					disableSupervisorFields();
					disablePDFields();
					
					showHidePreScreenFields();
					break;
				case "screen":
					control = formContext.getControl("header_process_sbagcbd_draftcompletedon"); if (control) control.setDisabled(true);
					disablePreScreenFields();
					disableProcessFields();
					disableSupervisorFields();
					disablePDFields();
					
					showHideScreenFields();
					break;
				case "process":
					control = formContext.getControl("header_process_sbagcbd_draftcompletedon"); if (control) control.setDisabled(true);
					disablePreScreenFields();
					disableScreenFields();
					disableSupervisorFields();
					disablePDFields();
					
					showHideProcessFields();
					break;
				case "supervisor review":
					control = formContext.getControl("header_process_sbagcbd_draftcompletedon"); if (control) control.setDisabled(true);
					disablePreScreenFields();
					disableScreenFields();
					disableProcessFields();
					disablePDFields();
					
					showHideSupervisorFields();
					break;
				case "pd review":
					control = formContext.getControl("header_process_sbagcbd_draftcompletedon"); if (control) control.setDisabled(true);
					disablePreScreenFields();
					disableScreenFields();
					disableProcessFields();
					disableSupervisorFields();
					
					showHidePDFields();
					break;
			}
		}
	}
	catch(err) {}
}

function disablePreScreenFields()
{
	control = formContext.getControl("header_process_sbagcbd_prescreenstatusnotes"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_prescreenphasestatus"); if (control) control.setDisabled(true);
	
	control = formContext.getControl("header_process_sbagcbd_pscsbeproofofcitizenship"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pscsbesuspensiondebarment"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pscctradelicenses"); if (control) control.setDisabled(true);
	
	control = formContext.getControl("header_process_sbagcbd_pscoc8acertification"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pscocthirdpartycertification"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pscoccve"); if (control) control.setDisabled(true);
	
	control = formContext.getControl("header_process_sbagcbd_pscoreapplyapplicant"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_psccresumeofthewomenholdingthehighestoffi"); if (control) control.setDisabled(true);

	control = formContext.getControl("header_process_sbagcbd_psccanybuysellagreements"); if (control) control.setDisabled(true);
	
	control = formContext.getControl("header_process_sbagcbd_pscedtaxreturnspersonalbusiness"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pscedfinancialdata"); if (control) control.setDisabled(true);
	
	control = formContext.getControl("header_process_sbagcbd_psciceconomicdisadvantagespouse"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pscicfamilyfederalemployee"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pscicfederalemployee"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pscicfulltimedevotion"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pscicproofofcitizenship"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pscictradelicenses"); if (control) control.setDisabled(true);	
	control = formContext.getControl("header_process_sbagcbd_pscicresume"); if (control) control.setDisabled(true);

	
	control = formContext.getControl("header_process_sbagcbd_pscocallissuedstockcertificates"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pscocarticlesofincorporationandanyamendme"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pscocassumedficticiousnamecertificate"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pscocbylawsandanyamendments"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pscoccorporatedocuments"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pscocstockledger"); if (control) control.setDisabled(true);
	
	control = formContext.getControl("header_process_sbagcbd_pscollcarticlesoforganizationandany"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pscollcassumedficticiousnamecertificate"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pscollcmembersmeetingminutes"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pscollcmembershipsharesifapplicable"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pscollcoperatingagreementandanyamendm"); if (control) control.setDisabled(true);
	
	control = formContext.getControl("header_process_sbagcbd_pscopassumedficticiousnamecertificate"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pscoppartnershipagreementandanyamendm"); if (control) control.setDisabled(true);
	
	control = formContext.getControl("header_process_sbagcbd_pscospassumedficticiousnamecertificate"); if (control) control.setDisabled(true);
	
}

function disableScreenFields()
{

	
	control = formContext.getControl("header_process_sbagcbd_screenstatusnotes"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_screen_phase_status"); if (control) control.setDisabled(true);
	
	control = formContext.getControl("header_process_sbagcbd_sccve"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_scthirdpartycertification"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_scsubpensiondebarment"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_scresumeofthewomenholdingthehighestof"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_screapplyapplicantletter"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_screapplyapplicantletter"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_scproofofcitizenship"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_scedfinancialdata"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_scedtaxreturnspersonalbusiness"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_sc8acertification"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_scanyagreementsbuysellvotingjv"); if (control) control.setDisabled(true);	
	
	control = formContext.getControl("header_process_sbagcbd_sciceconomicdisadvantagespouse"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_scicfederalemployee"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_scicfulltimedevotion"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_scicproofofcitizenship"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_scicresume"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_scictradelicenses"); if (control) control.setDisabled(true);
	
	control = formContext.getControl("header_process_sbagcbd_sccorpallissuedstockcertificates"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_sccorparticlesofincorporationandanyam"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_sccorpassumedfictitiousnamecert"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_sccorpbylawsandanyamendment"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_sccorporatedocumentsmeetingminutes"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_sccorpstockledger"); if (control) control.setDisabled(true);
	
	control = formContext.getControl("header_process_sbagcbd_scllcarticlesoforganizationandanyamen"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_scllcmembersmeetingminutes"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_scllcoperatingagreementandanyamend"); if (control) control.setDisabled(true);
	
	control = formContext.getControl("header_process_sbagcbd_scpartnershipassumedfictitiousnamecer"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_scpartnershipagreementandanyamendment"); if (control) control.setDisabled(true);
	
	control = formContext.getControl("header_process_sbagcbd_scsolepropassumedfictitiousnamecert"); if (control) control.setDisabled(true);		
	
	

}

function disableProcessFields()
{
	debugger;
	control = formContext.getControl("header_process_sbagcbd_processstatusnotes"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_processing_phase_status"); if (control) control.setDisabled(true);

	control = formContext.getControl("header_process_sbagcbd_prcve"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_prthirdpartycertification"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_prsuspensiondebarment"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_prresumeofthewomenholdingthehighest"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_prreapplyapplicantletter"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_prproofofcitizenship"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_predfinancialdata"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_predtaxreturnspersonalbusiness"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pr8acertification"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pranyagreementsbuysellvotingjv"); if (control) control.setDisabled(true);
	
	control = formContext.getControl("header_process_sbagcbd_priceconomicdisadvantagespouse"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pricfederalemployee"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pricfulltimedevotion"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pricproofofcitizenship"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pricresume"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_prictradelicenses"); if (control) control.setDisabled(true);

	control = formContext.getControl("header_process_sbagcbd_prcorpallissuedstockcertificates"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_prcorparticlesofincorporationandanyam"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_prcorpassumedfictitiousnamecert"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_prcorpbylawsandanyamend"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_prcorporatedocumentsmeetingminutes"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_prcorpstockledger"); if (control) control.setDisabled(true);
	
	control = formContext.getControl("header_process_sbagcbd_prllcarticlesoforganizationandanyamen"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_prllcmembersmeetingminutes"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_prllcoperatingagreementandanyamend"); if (control) control.setDisabled(true);
	
	control = formContext.getControl("header_process_sbagcbd_prpartnershipassumefictitiousnamecert"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_prpartnershipagreementandanyamend"); if (control) control.setDisabled(true);
	
	control = formContext.getControl("header_process_sbagcbd_prsolepropassumedfictitiousnamecert"); if (control) control.setDisabled(true);	
	
}

function disableSupervisorFields()
{
	control = formContext.getControl("header_process_sbagcbd_supervisorstatusnotes"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_supervisor_review_stage_status"); if (control) control.setDisabled(true);	
	
	control = formContext.getControl("header_process_sbagcbd_srcve"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_srthirdpartycertification"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_srsuspensiondebarment"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_srresumeofthewomenholdingthehighest"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_srreapplyapplicantletter"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_srproofofcitizenship"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_sredfinancialdata"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_sredtaxreturnspersonalbusiness"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_sr8acertification"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_sranyagreementsbuysellvotingjv"); if (control) control.setDisabled(true);
	
	control = formContext.getControl("header_process_sbagcbd_sriceconomicdisadvantagespouse"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_sricfederalemployee"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_sricfulltimedevotion"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_sricproofofcitizenship"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_sricresume"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_srictradelicenses"); if (control) control.setDisabled(true);

	control = formContext.getControl("header_process_sbagcbd_srcorpallissuedstockcertificates"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_srcorparticlesofincorporationandanyam"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_srcorpassumedfictitiousnamecert"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_srcorpbylawsandanyamendments"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_srcorporatedocuments"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_srcorpstockledger"); if (control) control.setDisabled(true);
	
	control = formContext.getControl("header_process_sbagcbd_srllcarticlesoforganizationandanyamen"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_srllcmembersmeetingminutes"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_srllcoperatingagreementandanyamend"); if (control) control.setDisabled(true);
	
	control = formContext.getControl("header_process_sbagcbd_srpartnershipassumedfictitiousnamecer"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_srpartnershipagreementandanyamend"); if (control) control.setDisabled(true);
	
	control = formContext.getControl("header_process_sbagcbd_srsolepropassumedfictitiousnamecert"); if (control) control.setDisabled(true);
}

function disablePDFields()
{
	control = formContext.getControl("header_process_sbagcbd_pdstatusnotes"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pd_phase_status"); if (control) control.setDisabled(true);	

	control = formContext.getControl("header_process_sbagcbd_pdcve"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pdthirdpartycertification"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pdsuspensiondebarment"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pdresumeofthewomenholdingthehighest"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pdreapplyapplicantletter"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pdproofofcitizenship"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pdedfinancialdata"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pdedtaxreturnspersonalbusiness"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pd8acertification"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pdanyagreementsbuysellvotingjv"); if (control) control.setDisabled(true);
	
	control = formContext.getControl("header_process_sbagcbd_pdiceconomicdisadvantagespouse"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pdicfederalemployee"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pdicfulltimedevotion"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pdicproofofcitizenship"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pdicresume"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pdictradelicenses"); if (control) control.setDisabled(true);

	control = formContext.getControl("header_process_sbagcbd_pdcorpallissuedstockcertificates"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pdcorparticlesofincorporationandanyam"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pdcorpassumedfictitiousnamecertificat"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pdcorpbylawsandanyamendment"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pdcorporatedocumentsmeetingminutes"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pdcorpstockledger"); if (control) control.setDisabled(true);
	
	control = formContext.getControl("header_process_sbagcbd_pdllcarticlesoforganizationandanyamen"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pdllcmembersmeetingminutes"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pdllcoperatingagreementandanyamend"); if (control) control.setDisabled(true);
	
	control = formContext.getControl("header_process_sbagcbd_pdpartnershipassumedfictitiousnamecer"); if (control) control.setDisabled(true);
	control = formContext.getControl("header_process_sbagcbd_pdpartnershipagreementandanyamendment"); if (control) control.setDisabled(true);
	
	control = formContext.getControl("header_process_sbagcbd_pdsolepropassumedfictitiousnamecertif"); if (control) control.setDisabled(true);
//debugger;
	control = formContext.getControl("header_process_sbagcbd_processing_phase_status_1"); if (control) control.setDisabled(true);	
}

function showHidePreScreenFields()
{
	try
	{
		var hasIndividualContributors = formContext.getAttribute("sbagcbd_hasindividualcontributors").getValue();
		var businessType = formContext.getAttribute("sbagcbd_confirmedbusinesstype").getValue();
		
		var control;
		
		//Don't show certification checklists and default to YES
		control = formContext.getControl("header_process_sbagcbd_pscoc8acertification"); if (control) control.setVisible(calculate8a());
		control = formContext.getControl("header_process_sbagcbd_pscocthirdpartycertification"); if (control) control.setVisible(calculateTPC());
		control = formContext.getControl("header_process_sbagcbd_pscoccve"); if (control) control.setVisible(calculateCVE());

		if(!calculate8a())
			setBoolean("sbagcbd_pscoc8acertification", true);		
		if(!calculateTPC())
			setBoolean("sbagcbd_pscocthirdpartycertification", true);
		if(!calculateCVE())
			setBoolean("sbagcbd_pscoccve", true);

		
		// Pre-Screen
		
		// Individual Contributor Fields
		if (hasIndividualContributors != null && hasIndividualContributors)
		{
			control = formContext.getControl("header_process_sbagcbd_psciceconomicdisadvantagespouse"); if (control) control.setVisible(true);
			control = formContext.getControl("header_process_sbagcbd_pscicfamilyfederalemployee"); if (control) control.setVisible(true);
			control = formContext.getControl("header_process_sbagcbd_pscicfederalemployee"); if (control) control.setVisible(true);
			control = formContext.getControl("header_process_sbagcbd_pscicfulltimedevotion"); if (control) control.setVisible(true);
			control = formContext.getControl("header_process_sbagcbd_pscicproofofcitizenship"); if (control) control.setVisible(true);
			control = formContext.getControl("header_process_sbagcbd_pscictradelicenses"); if (control) control.setVisible(true);
		}
		else
		{
			control = formContext.getControl("header_process_sbagcbd_psciceconomicdisadvantagespouse"); if (control) control.setVisible(false);
			control = formContext.getControl("header_process_sbagcbd_pscicfamilyfederalemployee"); if (control) control.setVisible(false);
			control = formContext.getControl("header_process_sbagcbd_pscicfederalemployee"); if (control) control.setVisible(false);
			control = formContext.getControl("header_process_sbagcbd_pscicfulltimedevotion"); if (control) control.setVisible(false);
			control = formContext.getControl("header_process_sbagcbd_pscicproofofcitizenship"); if (control) control.setVisible(false);
			control = formContext.getControl("header_process_sbagcbd_pscicresume"); if (control) control.setVisible(false);
			control = formContext.getControl("header_process_sbagcbd_pscictradelicenses"); if (control) control.setVisible(false);
		}
		
		// Business Type Fields
		
		control = formContext.getControl("header_process_sbagcbd_pscocallissuedstockcertificates"); if (control) control.setVisible(false);
		control = formContext.getControl("header_process_sbagcbd_pscocarticlesofincorporationandanyamendme"); if (control) control.setVisible(false);
		control = formContext.getControl("header_process_sbagcbd_pscocassumedficticiousnamecertificate"); if (control) control.setVisible(false);
		control = formContext.getControl("header_process_sbagcbd_pscocbylawsandanyamendments"); if (control) control.setVisible(false);
		control = formContext.getControl("header_process_sbagcbd_pscoccorporatedocuments"); if (control) control.setVisible(false);
		control = formContext.getControl("header_process_sbagcbd_pscocstockledger"); if (control) control.setVisible(false);
		control = formContext.getControl("header_process_sbagcbd_pscollcarticlesoforganizationandany"); if (control) control.setVisible(false);
		control = formContext.getControl("header_process_sbagcbd_pscollcassumedficticiousnamecertificate"); if (control) control.setVisible(false);
		control = formContext.getControl("header_process_sbagcbd_pscollcmembersmeetingminutes"); if (control) control.setVisible(false);
		control = formContext.getControl("header_process_sbagcbd_pscollcmembershipsharesifapplicable"); if (control) control.setVisible(false);
		control = formContext.getControl("header_process_sbagcbd_pscollcoperatingagreementandanyamendm"); if (control) control.setVisible(false);
		control = formContext.getControl("header_process_sbagcbd_pscopassumedficticiousnamecertificate"); if (control) control.setVisible(false);
		control = formContext.getControl("header_process_sbagcbd_pscoppartnershipagreementandanyamendm"); if (control) control.setVisible(false);
		control = formContext.getControl("header_process_sbagcbd_pscospassumedficticiousnamecertificate"); if (control) control.setVisible(false);
				
		if (businessType != null)
		{
			//debugger;
			if (businessType.toLowerCase().includes("corp") == false) // Corporation
			{
				setBoolean("sbagcbd_pscocallissuedstockcertificates", true);
				setBoolean("sbagcbd_pscocarticlesofincorporationandanyamendme", true);
				setBoolean("sbagcbd_pscocassumedficticiousnamecertificate", true);
				setBoolean("sbagcbd_pscocbylawsandanyamendments", true);
				setBoolean("sbagcbd_pscoccorporatedocuments", true);
				setBoolean("sbagcbd_pscocstockledger", true);
			}
			if (businessType.toLowerCase().includes("llc") == false)	// LLC
			{
				setBoolean("sbagcbd_pscollcarticlesoforganizationandany", true);
				setBoolean("sbagcbd_pscollcassumedficticiousnamecertificate", true);
				setBoolean("sbagcbd_pscollcmembersmeetingminutes", true);
				setBoolean("sbagcbd_pscollcmembershipsharesifapplicable", true);
				setBoolean("sbagcbd_pscollcoperatingagreementandanyamendm", true);
			}
			if (businessType.toLowerCase().includes("partnership") == false)	// Partnership
			{
				setBoolean("sbagcbd_pscopassumedficticiousnamecertificate", true);
				setBoolean("sbagcbd_pscoppartnershipagreementandanyamendm", true);
			}
			if (businessType.toLowerCase().includes("sole") == false)	// Sole Proprietorship
			{
				setBoolean("sbagcbd_pscospassumedficticiousnamecertificate", true);
			}


			if (businessType.toLowerCase().includes("corp") == true)	// Corporation
			{
				control = formContext.getControl("header_process_sbagcbd_pscocallissuedstockcertificates"); if (control) control.setVisible(true);
				control = formContext.getControl("header_process_sbagcbd_pscocarticlesofincorporationandanyamendme"); if (control) control.setVisible(true);
				control = formContext.getControl("header_process_sbagcbd_pscocassumedficticiousnamecertificate"); if (control) control.setVisible(true);
				control = formContext.getControl("header_process_sbagcbd_pscocbylawsandanyamendments"); if (control) control.setVisible(true);
				control = formContext.getControl("header_process_sbagcbd_pscoccorporatedocuments"); if (control) control.setVisible(true);
				control = formContext.getControl("header_process_sbagcbd_pscocstockledger"); if (control) control.setVisible(true);
			}
			else if (businessType.toLowerCase().includes("llc") == true)	// LLC
			{
				control = formContext.getControl("header_process_sbagcbd_pscollcarticlesoforganizationandany"); if (control) control.setVisible(true);
				control = formContext.getControl("header_process_sbagcbd_pscollcassumedficticiousnamecertificate"); if (control) control.setVisible(true);
				control = formContext.getControl("header_process_sbagcbd_pscollcmembersmeetingminutes"); if (control) control.setVisible(true);
				control = formContext.getControl("header_process_sbagcbd_pscollcmembershipsharesifapplicable"); if (control) control.setVisible(true);
				control = formContext.getControl("header_process_sbagcbd_pscollcoperatingagreementandanyamendm"); if (control) control.setVisible(true);
			}
			else if (businessType.toLowerCase().includes("partnership") == true)	// Partnership
			{
				control = formContext.getControl("header_process_sbagcbd_pscopassumedficticiousnamecertificate"); if (control) control.setVisible(true);
				control = formContext.getControl("header_process_sbagcbd_pscoppartnershipagreementandanyamendm"); if (control) control.setVisible(true);
			}
			else if (businessType.toLowerCase().includes("sole") == true)	// Sole Proprietorship
			{
				control = formContext.getControl("header_process_sbagcbd_pscospassumedficticiousnamecertificate"); if (control) control.setVisible(true);
			}
		}	
		if (hasIndividualContributors != null && !hasIndividualContributors)
		{
			setBoolean("sbagcbd_psciceconomicdisadvantagespouse", true);
			setBoolean("sbagcbd_pscicfamilyfederalemployee", true);
			setBoolean("sbagcbd_pscicfederalemployee", true);
			setBoolean("sbagcbd_pscicfulltimedevotion", true);
			setBoolean("sbagcbd_pscicproofofcitizenship", true);
			setBoolean("sbagcbd_pscicresume", true);
			setBoolean("sbagcbd_pscictradelicenses", true);		
		}
	}
	catch(err)
	{
		
	}
}

function showHideScreenFields()
{
	try
	{
		var hasIndividualContributors = formContext.getAttribute("sbagcbd_hasindividualcontributors").getValue();
		var businessType = formContext.getAttribute("sbagcbd_confirmedbusinesstype").getValue();
		
		var control = null;
		var visible = false;
		
		//Don't show certification checklists and default to YES
		control = formContext.getControl("header_process_sbagcbd_sc8acertification"); if (control) control.setVisible(calculate8a());
		control = formContext.getControl("header_process_sbagcbd_scthirdpartycertification"); if (control) control.setVisible(calculateTPC());
		control = formContext.getControl("header_process_sbagcbd_sccve"); if (control) control.setVisible(calculateCVE());

		if(!calculate8a())
			setBoolean("sbagcbd_sc8acertification", true);		
		if(!calculateTPC())
			setBoolean("sbagcbd_scthirdpartycertification", true);
		if(!calculateCVE())
			setBoolean("sbagcbd_sccve", true);

		// Pre-Screen
		
		// Individual Contributor Fields
		if (hasIndividualContributors != null && hasIndividualContributors)
		{
			visible = true;
		}
		else
		{
			visible = false;
		}
		
		var corpVisible = false;
		var llcVisible = false;
		var partnershipVisible = false;
		var soleVisible = false;
		
		//setBoolean("sbagcbd_sctradelicenses"), true);
		
		if (businessType != null)
		{
			if(businessType.toLowerCase().includes("corp") == false)
			{
				setBoolean("sbagcbd_sccorpallissuedstockcertificates",true);
				setBoolean("sbagcbd_sccorparticlesofincorporationandanyam",true);
				setBoolean("sbagcbd_sccorpassumedfictitiousnamecert",true);
				setBoolean("sbagcbd_sccorpbylawsandanyamendment",true);
				setBoolean("sbagcbd_sccorporatedocumentsmeetingminutes",true);
				setBoolean("sbagcbd_sccorpstockledger",true);				
			}
			if(businessType.toLowerCase().includes("llc") == false)
			{
				setBoolean("sbagcbd_scllcarticlesoforganizationandanyamen",true);
				setBoolean("sbagcbd_scllcmembersmeetingminutes",true);
				setBoolean("sbagcbd_scllcoperatingagreementandanyamend",true);					
			}
			if(businessType.toLowerCase().includes("partnership") == false)
			{
				setBoolean("sbagcbd_scpartnershipassumedfictitiousnamecer",true);					
				setBoolean("sbagcbd_scpartnershipagreementandanyamendment",true);					
			}
			if(businessType.toLowerCase().includes("sole") == false)
			{
				setBoolean("sbagcbd_scsolepropassumedfictitiousnamecert",true);					
			}
			
			if(businessType.toLowerCase().includes("corp") == true)
			{
				corpVisible = true;
			}
			else if(businessType.toLowerCase().includes("llc") == true)
			{
				llcVisible = true;
			}
			else if(businessType.toLowerCase().includes("partnership") == true)
			{
				partnershipVisible = true;
			}
			else if(businessType.toLowerCase().includes("sole") == true)
			{
				soleVisible = true;
			}
				
			
			// switch (businessType)
			// {
				// case 517220003:
					// corpVisible = true;
					// break;
				// case 517220000:
					// llcVisible = true;
					// break;
				// case 517220001:
					// partnershipVisible = true;
					// break;
				// case 517220002:
					// soleVisible = true;
					// break;
			// }
		}
		if (hasIndividualContributors != null && !hasIndividualContributors)
		{
			setBoolean("sbagcbd_sciceconomicdisadvantagespouse", true);
			setBoolean("sbagcbd_scicfamilyfederalemployee", true);
			setBoolean("sbagcbd_scicfederalemployee", true);
			setBoolean("sbagcbd_scicfulltimedevotion", true);
			setBoolean("sbagcbd_scicproofofcitizenship", true);
			setBoolean("sbagcbd_scicresume", true);
			setBoolean("sbagcbd_scictradelicenses", true);		
		}

		// control = formContext.getControl("header_process_sbagcbd_sccve"); if (control) control.setVisible(true);
		// control = formContext.getControl("header_process_sbagcbd_scthirdpartycertification"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_scsuspensiondebarment"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_scresumeofthewomenholdingthehighestof"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_screapplyapplicantletter"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_scproofofcitizenship"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_scedfinancialdata"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_scedtaxreturspersonalbusiness"); if (control) control.setVisible(true);
		// control = formContext.getControl("header_process_sbagcbd_sc8acertification"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_scanyagreementsbuysellvotingjv"); if (control) control.setVisible(true);
		
		
		control = formContext.getControl("header_process_sbagcbd_sciceconomicdisadvantagespouse"); if (control) control.setVisible(visible);
		control = formContext.getControl("header_process_sbagcbd_scicfederalemployee"); if (control) control.setVisible(visible);
		control = formContext.getControl("header_process_sbagcbd_scicfulltimedevotion"); if (control) control.setVisible(visible);
		control = formContext.getControl("header_process_sbagcbd_scicproofofcitizenship"); if (control) control.setVisible(visible);
		control = formContext.getControl("header_process_sbagcbd_scicresume"); if (control) control.setVisible(visible);
		control = formContext.getControl("header_process_sbagcbd_scictradelicenses"); if (control) control.setVisible(visible);
		
		// Business Type Fields
		// Hide all fields for business type and then turn them on based on the businessType
		
		control = formContext.getControl("header_process_sbagcbd_sccorpallissuedstockcertificates"); if (control) control.setVisible(corpVisible);
		control = formContext.getControl("header_process_sbagcbd_sccorparticlesofincorporationandanyam"); if (control) control.setVisible(corpVisible);
		control = formContext.getControl("header_process_sbagcbd_sccorpassumedficticiousnamecert"); if (control) control.setVisible(corpVisible);
		control = formContext.getControl("header_process_sbagcbd_sccorpbylawsandanyamendment"); if (control) control.setVisible(corpVisible);
		control = formContext.getControl("header_process_sbagcbd_sccorporatedocumentsmeetingminutes"); if (control) control.setVisible(corpVisible);
		control = formContext.getControl("header_process_sbagcbd_sccorpstockledger"); if (control) control.setVisible(corpVisible);
		
		control = formContext.getControl("header_process_sbagcbd_scllcarticlesoforganizationandanyamen"); if (control) control.setVisible(llcVisible);
		control = formContext.getControl("header_process_sbagcbd_scllcmembersmeetingminutes"); if (control) control.setVisible(llcVisible);
		control = formContext.getControl("header_process_sbagcbd_scllcoperatingagreementandanyamend"); if (control) control.setVisible(llcVisible);
		
		control = formContext.getControl("header_process_sbagcbd_scpartnershipassumedfictitiousnamecer"); if (control) control.setVisible(partnershipVisible);
		control = formContext.getControl("header_process_sbagcbd_scpartnershipagreementandanyamendment"); if (control) control.setVisible(partnershipVisible);
		
		control = formContext.getControl("header_process_sbagcbd_scsolepropassumedfictitiousnamecert"); if (control) control.setVisible(soleVisible);		

	}
	catch(err)	{ }
}

function showHideProcessFields()
{
	try
	{
		var hasIndividualContributors = formContext.getAttribute("sbagcbd_hasindividualcontributors").getValue();
		var businessType = formContext.getAttribute("sbagcbd_confirmedbusinesstype").getValue();
		
		var control;
		var visible;
		
		//Don't show certification checklists and default to YES
		control = formContext.getControl("header_process_sbagcbd_pr8acertification"); if (control) control.setVisible(calculate8a());
		control = formContext.getControl("header_process_sbagcbd_prthirdpartycertification"); if (control) control.setVisible(calculateTPC());
		control = formContext.getControl("header_process_sbagcbd_prcve"); if (control) control.setVisible(calculateCVE());

		if(!calculate8a())
			setBoolean("sbagcbd_pr8acertification", true);		
		if(!calculateTPC())
			setBoolean("sbagcbd_prthirdpartycertification", true);
		if(!calculateCVE())
			setBoolean("sbagcbd_prcve", true);
		
		// Pre-Screen
		
		// Individual Contributor Fields
		if (hasIndividualContributors != null && hasIndividualContributors)
		{
			visible = true;
		}
		else
		{
			visible = false;
		}
		
		var corpVisible = false;
		var llcVisible = false;
		var partnershipVisible = false;
		var soleVisible = false;
		
		if (businessType != null)
		{
			if(businessType.toLowerCase().includes("corp") == false)
			{
				setBoolean("sbagcbd_prcorpallissuedstockcertificates",true);
				setBoolean("sbagcbd_prcorparticlesofincorporationandanyam",true);
				setBoolean("sbagcbd_prcorpassumedficticiousnamecert",true);
				setBoolean("sbagcbd_prcorpbylawsandanyamendment",true);
				setBoolean("sbagcbd_prcorporatedocumentsmeetingminutes",true);
				setBoolean("sbagcbd_prcorpstockledger",true);				
			}
			if(businessType.toLowerCase().includes("llc") == false)
			{
				setBoolean("sbagcbd_prllcarticlesoforganizationandanyamen",true);
				setBoolean("sbagcbd_prllcmembersmeetingminutes",true);
				setBoolean("sbagcbd_prllcoperatingagreementandanyamend",true);					
			}
			if(businessType.toLowerCase().includes("partnership") == false)
			{
				setBoolean("sbagcbd_prparnershipassumedfictitiousnamecer",true);					
				setBoolean("sbagcbd_prpartnershipagreementandanyamendment",true);					
			}
			if(businessType.toLowerCase().includes("sole") == false)
			{
				setBoolean("sbagcbd_prsolepropassumedfictitiousnamecert",true);					
			}
			
			if(businessType.toLowerCase().includes("corp") == true)
			{
				corpVisible = true;
			}
			else if(businessType.toLowerCase().includes("llc") == true)
			{
				llcVisible = true;
			}
			else if(businessType.toLowerCase().includes("partnership") == true)
			{
				partnershipVisible = true;
			}
			else if(businessType.toLowerCase().includes("sole") == true)
			{
				soleVisible = true;
			}
			
			// switch (businessType)
			// {
				// case 517220003:
					// corpVisible = true;
					// break;
				// case 517220000:
					// llcVisible = true;
					// break;
				// case 517220001:
					// partnershipVisible = true;
					// break;
				// case 517220002:
					// soleVisible = true;
					// break;
			// }
		}

		if (hasIndividualContributors != null && !hasIndividualContributors)
		{
			setBoolean("sbagcbd_priceconomicdisadvantagespouse", true);
			setBoolean("sbagcbd_pricfamilyfederalemployee", true);
			setBoolean("sbagcbd_pricfederalemployee", true);
			setBoolean("sbagcbd_pricfulltimedevotion", true);
			setBoolean("sbagcbd_pricproofofcitizenship", true);
			setBoolean("sbagcbd_pricresume", true);
			setBoolean("sbagcbd_prictradelicenses", true);		
		}		
		
		// control = formContext.getControl("header_process_sbagcbd_prcve"); if (control) control.setVisible(true);
		// control = formContext.getControl("header_process_sbagcbd_prthirdpartycertification"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_prsuspensiondebarment"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_prresumeofthewomenholdingthehighest"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_prreapplyapplicantletter"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_prproofofcitizenship"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_predfinancialdata"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_predtaxreturspersonalbusiness"); if (control) control.setVisible(true);
		// control = formContext.getControl("header_process_sbagcbd_pr8acertification"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_pranyagreementsbuysellvotingjv"); if (control) control.setVisible(true);
		
		control = formContext.getControl("header_process_sbagcbd_priceconomicdisadvantagespouse"); if (control) control.setVisible(visible);
		control = formContext.getControl("header_process_sbagcbd_pricfederalemployee"); if (control) control.setVisible(visible);
		control = formContext.getControl("header_process_sbagcbd_pricfulltimedevotion"); if (control) control.setVisible(visible);
		control = formContext.getControl("header_process_sbagcbd_pricproofofcitizenship"); if (control) control.setVisible(visible);
		control = formContext.getControl("header_process_sbagcbd_pricresume"); if (control) control.setVisible(visible);
		control = formContext.getControl("header_process_sbagcbd_prictradelicenses"); if (control) control.setVisible(visible);
		
		// Business Type Fields
		// Hide all fields for business type and then turn them on based on the businessType
		
		control = formContext.getControl("header_process_sbagcbd_prcorpallissuedstockcertificates"); if (control) control.setVisible(corpVisible);
		control = formContext.getControl("header_process_sbagcbd_prcorparticlesofincorporationandanyam"); if (control) control.setVisible(corpVisible);
		control = formContext.getControl("header_process_sbagcbd_prcorpassumedficticiousnamecert"); if (control) control.setVisible(corpVisible);
		control = formContext.getControl("header_process_sbagcbd_prcorpbylawsandanyamendment"); if (control) control.setVisible(corpVisible);
		control = formContext.getControl("header_process_sbagcbd_prcorporatedocumentsmeetingminutes"); if (control) control.setVisible(corpVisible);
		control = formContext.getControl("header_process_sbagcbd_prcorpstockledger"); if (control) control.setVisible(corpVisible);
		
		control = formContext.getControl("header_process_sbagcbd_prllcarticlesoforganizationandanyamen"); if (control) control.setVisible(llcVisible);
		control = formContext.getControl("header_process_sbagcbd_prllcmembersmeetingminutes"); if (control) control.setVisible(llcVisible);
		control = formContext.getControl("header_process_sbagcbd_prllcoperatingagreementandanyamend"); if (control) control.setVisible(llcVisible);
		
		control = formContext.getControl("header_process_sbagcbd_prparnershipassumedfictitiousnamecer"); if (control) control.setVisible(partnershipVisible);
		control = formContext.getControl("header_process_sbagcbd_prpartnershipagreementandanyamendment"); if (control) control.setVisible(partnershipVisible);
		
		control = formContext.getControl("header_process_sbagcbd_prsolepropassumedficticiousnamecert"); if (control) control.setVisible(soleVisible);		
	}
	catch(err)
	{
		
	}
}

function showHideSupervisorFields()
{
	try
	{
		var hasIndividualContributors = formContext.getAttribute("sbagcbd_hasindividualcontributors").getValue();
		var businessType = formContext.getAttribute("sbagcbd_confirmedbusinesstype").getValue();
		
		var control;
		var visible;
		
		//Don't show certification checklists and default to YES
		control = formContext.getControl("header_process_sbagcbd_sr8acertification"); if (control) control.setVisible(calculate8a());
		control = formContext.getControl("header_process_sbagcbd_srthirdpartycertification"); if (control) control.setVisible(calculateTPC());
		control = formContext.getControl("header_process_sbagcbd_srcve"); if (control) control.setVisible(calculateCVE());

		if(!calculate8a())
			setBoolean("sbagcbd_sr8acertification", true);		
		if(!calculateTPC())
			setBoolean("sbagcbd_srthirdpartycertification", true);
		if(!calculateCVE())
			setBoolean("sbagcbd_srcve", true);		
		
		// Pre-Screen
		
		// Individual Contributor Fields
		if (hasIndividualContributors != null && hasIndividualContributors)
		{
			visible = true;
		}
		else
		{
			visible = false;
		}
		
		var corpVisible = false;
		var llcVisible = false;
		var partnershipVisible = false;
		var soleVisible = false;
		
		if (businessType != null)
		{
			if(businessType.toLowerCase().includes("corp") == false)
			{
				setBoolean("sbagcbd_srcorpallissuedstockcertificates",true);
				setBoolean("sbagcbd_srcorparticlesofincorporationandanyam",true);
				setBoolean("sbagcbd_srcorpassumedficticiousnamecert",true);
				setBoolean("sbagcbd_srcorpbylawsandanyamendmen",true);
				setBoolean("sbagcbd_srcorporatedocumentsmeetingminutes",true);
				setBoolean("sbagcbd_srcorpstockledger",true);				
			}
			if(businessType.toLowerCase().includes("llc") == false)
			{
				setBoolean("sbagcbd_srllcarticlesoforganizationandanyamen",true);
				setBoolean("sbagcbd_srllcmembersmeetingminutes",true);
				setBoolean("sbagcbd_srllcoperatingagreementandanyamend",true);					
			}
			if(businessType.toLowerCase().includes("partnership") == false)
			{
				setBoolean("sbagcbd_srparnershipassumedfictitiousnamecer",true);					
				setBoolean("sbagcbd_srpartnershipagreementandanyamendment",true);					
			}
			if(businessType.toLowerCase().includes("sole") == false)
			{
				setBoolean("sbagcbd_srsolepropassumedficticiousnamecert",true);					
			}
			
			if(businessType.toLowerCase().includes("corp") == true)
			{
				corpVisible = true;
			}
			else if(businessType.toLowerCase().includes("llc") == true)
			{
				llcVisible = true;
			}
			else if(businessType.toLowerCase().includes("partnership") == true)
			{
				partnershipVisible = true;
			}
			else if(businessType.toLowerCase().includes("sole") == true)
			{
				soleVisible = true;
			}			
			
			// switch (businessType)
			// {
				// case 517220003:
					// corpVisible = true;
					// break;
				// case 517220000:
					// llcVisible = true;
					// break;
				// case 517220001:
					// partnershipVisible = true;
					// break;
				// case 517220002:
					// soleVisible = true;
					// break;
			// }
		}
		if (hasIndividualContributors != null && !hasIndividualContributors)
		{
			setBoolean("sbagcbd_sriceconomicdisadvantagespouse", true);
			setBoolean("sbagcbd_sricfamilyfederalemployee", true);
			setBoolean("sbagcbd_sricfederalemployee", true);
			setBoolean("sbagcbd_sricfulltimedevotion", true);
			setBoolean("sbagcbd_sricproofofcitizenship", true);
			setBoolean("sbagcbd_sricresume", true);
			setBoolean("sbagcbd_srictradelicenses", true);		
		}		
		
		//control = formContext.getControl("header_process_sbagcbd_srcve"); if (control) control.setVisible(true);
		//control = formContext.getControl("header_process_sbagcbd_srthirdpartycertification"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_srsuspensiondebarment"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_srresumeofthewomenholdingthehighest"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_srreapplyapplicantletter"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_srproofofcitizenship"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_sredfinancialdata"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_sredtaxreturspersonalbusiness"); if (control) control.setVisible(true);
		//control = formContext.getControl("header_process_sbagcbd_sr8acertification"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_sranyagreementsbuysellvotingjv"); if (control) control.setVisible(true);
		
		control = formContext.getControl("header_process_sbagcbd_sriceconomicdisadvantagespouse"); if (control) control.setVisible(visible);
		control = formContext.getControl("header_process_sbagcbd_sricfederalemployee"); if (control) control.setVisible(visible);
		control = formContext.getControl("header_process_sbagcbd_sricfulltimedevotion"); if (control) control.setVisible(visible);
		control = formContext.getControl("header_process_sbagcbd_sricproofofcitizenship"); if (control) control.setVisible(visible);
		control = formContext.getControl("header_process_sbagcbd_sricresume"); if (control) control.setVisible(visible);
		control = formContext.getControl("header_process_sbagcbd_srictradelicenses"); if (control) control.setVisible(visible);
		
		// Business Type Fields
		// Hide all fields for business type and then turn them on based on the businessType
		
		control = formContext.getControl("header_process_sbagcbd_srcorpallissuedstockcertificates"); if (control) control.setVisible(corpVisible);
		control = formContext.getControl("header_process_sbagcbd_srcorparticlesofincorporationandanyam"); if (control) control.setVisible(corpVisible);
		control = formContext.getControl("header_process_sbagcbd_srcorpassumedficticiousnamecert"); if (control) control.setVisible(corpVisible);
		control = formContext.getControl("header_process_sbagcbd_srcorpbylawsandanyamendment"); if (control) control.setVisible(corpVisible);
		control = formContext.getControl("header_process_sbagcbd_srcorporatedocumentsmeetingminutes"); if (control) control.setVisible(corpVisible);
		control = formContext.getControl("header_process_sbagcbd_srcorpstockledger"); if (control) control.setVisible(corpVisible);
		
		control = formContext.getControl("header_process_sbagcbd_srllcarticlesoforganizationandanyamen"); if (control) control.setVisible(llcVisible);
		control = formContext.getControl("header_process_sbagcbd_srllcmembersmeetingminutes"); if (control) control.setVisible(llcVisible);
		control = formContext.getControl("header_process_sbagcbd_srllcoperatingagreementandanyamend"); if (control) control.setVisible(llcVisible);
		
		control = formContext.getControl("header_process_sbagcbd_srparnershipassumedfictitiousnamecer"); if (control) control.setVisible(partnershipVisible);
		control = formContext.getControl("header_process_sbagcbd_srpartnershipagreementandanyamendment"); if (control) control.setVisible(partnershipVisible);
		
		control = formContext.getControl("header_process_sbagcbd_srsolepropassumedficticiousnamecert"); if (control) control.setVisible(soleVisible);		
	}
	catch(err)
	{
		
	}
}

function showHidePDFields()
{
	try
	{
		var hasIndividualContributors = formContext.getAttribute("sbagcbd_hasindividualcontributors").getValue();
		var businessType = formContext.getAttribute("sbagcbd_confirmedbusinesstype").getValue();
		
		var control;
		var visible;
		
		//Don't show certification checklists and default to YES
		control = formContext.getControl("header_process_sbagcbd_pd8acertification"); if (control) control.setVisible(calculate8a());
		control = formContext.getControl("header_process_sbagcbd_pdthirdpartycertification"); if (control) control.setVisible(calculateTPC());
		control = formContext.getControl("header_process_sbagcbd_pdcve"); if (control) control.setVisible(calculateCVE());
		debugger;
		// Disable the Process Stage field - it has to be in this stage as it's used in subsequent conditions in the BPF
		control = formContext.getControl("header_process_sbagcbd_processing_phase_status_1"); if (control) control.setDisabled(true);

		if(!calculate8a())
			setBoolean("sbagcbd_pd8acertification", true);		
		if(!calculateTPC())
			setBoolean("sbagcbd_pdthirdpartycertification", true);
		if(!calculateCVE())
			setBoolean("sbagcbd_pdcve", true);				
		
		// Pre-Screen
		
		// Individual Contributor Fields
		if (hasIndividualContributors != null && hasIndividualContributors)
		{
			visible = true;
		}
		else
		{
			visible = false;
		}
		
		var corpVisible = false;
		var llcVisible = false;
		var partnershipVisible = false;
		var soleVisible = false;
		
		if (businessType != null)
		{
			if(businessType.toLowerCase().includes("corp") == false)
			{
				setBoolean("sbagcbd_pdcorpallissuedstockcertificates",true);
				setBoolean("sbagcbd_pdcorparticlesofincorporationandanyam",true);
				setBoolean("sbagcbd_pdcorpassumedficticiousnamecert",true);
				setBoolean("sbagcbd_pdcorpbylawsandanyamendment",true);
				setBoolean("sbagcbd_pdcorporatedocumentsmeetingminutes",true);
				setBoolean("sbagcbd_pdcorpstockledger",true);				
			}
			if(businessType.toLowerCase().includes("llc") == false)
			{
				setBoolean("sbagcbd_pdllcarticlesoforganizationandanyamen",true);
				setBoolean("sbagcbd_pdllcmembersmeetingminutes",true);
				setBoolean("sbagcbd_pdllcoperatingagreementandanyamend",true);					
			}
			if(businessType.toLowerCase().includes("partnership") == false)
			{
				setBoolean("sbagcbd_pdparnershipassumedfictitiousnamecer",true);					
				setBoolean("sbagcbd_pdpartnershipagreementandanyamendment",true);					
			}
			if(businessType.toLowerCase().includes("sole") == false)
			{
				setBoolean("sbagcbd_pdsolepropassumedficticiousnamecertif",true);					
			}
			
			
			if(businessType.toLowerCase().includes("corp") == true)
			{
				corpVisible = true;
			}
			else if(businessType.toLowerCase().includes("llc") == true)
			{
				llcVisible = true;
			}
			else if(businessType.toLowerCase().includes("partnership") == true)
			{
				partnershipVisible = true;
			}
			else if(businessType.toLowerCase().includes("sole") == true)
			{
				soleVisible = true;
			}
			
			// switch (businessType)
			// {
				// case 517220003:
					// corpVisible = true;
					// break;
				// case 517220000:
					// llcVisible = true;
					// break;
				// case 517220001:
					// partnershipVisible = true;
					// break;
				// case 517220002:
					// soleVisible = true;
					// break;
			// }
		}
		if (hasIndividualContributors != null && !hasIndividualContributors)
		{
			setBoolean("sbagcbd_pdiceconomicdisadvantagespouse", true);
			setBoolean("sbagcbd_pdicfamilyfederalemployee", true);
			setBoolean("sbagcbd_pdicfederalemployee", true);
			setBoolean("sbagcbd_pdicfulltimedevotion", true);
			setBoolean("sbagcbd_pdicproofofcitizenship", true);
			setBoolean("sbagcbd_pdicresume", true);
			setBoolean("sbagcbd_pdictradelicenses", true);		
		}		
		
		//control = formContext.getControl("header_process_sbagcbd_pdcve"); if (control) control.setVisible(true);
		//control = formContext.getControl("header_process_sbagcbd_pdthirdpartycertification"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_pdsuspensiondebarment"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_pdresumeofthewomenholdingthehighest"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_pdreapplyapplicantletter"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_pdproofofcitizenship"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_pdedfinancialdata"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_pdedtaxreturspersonalbusiness"); if (control) control.setVisible(true);
		//control = formContext.getControl("header_process_sbagcbd_pd8acertification"); if (control) control.setVisible(true);
		control = formContext.getControl("header_process_sbagcbd_pdanyagreementsbuysellvotingjv"); if (control) control.setVisible(true);
		
		control = formContext.getControl("header_process_sbagcbd_pdiceconomicdisadvantagespouse"); if (control) control.setVisible(visible);
		control = formContext.getControl("header_process_sbagcbd_pdicfederalemployee"); if (control) control.setVisible(visible);
		control = formContext.getControl("header_process_sbagcbd_pdicfulltimedevotion"); if (control) control.setVisible(visible);
		control = formContext.getControl("header_process_sbagcbd_pdicproofofcitizenship"); if (control) control.setVisible(visible);
		control = formContext.getControl("header_process_sbagcbd_pdicresume"); if (control) control.setVisible(visible);
		control = formContext.getControl("header_process_sbagcbd_pdictradelicenses"); if (control) control.setVisible(visible);
		
		// Business Type Fields
		// Hide all fields for business type and then turn them on based on the businessType
		
		control = formContext.getControl("header_process_sbagcbd_pdcorpallissuedstockcertificates"); if (control) control.setVisible(corpVisible);
		control = formContext.getControl("header_process_sbagcbd_pdcorparticlesofincorporationandanyam"); if (control) control.setVisible(corpVisible);
		control = formContext.getControl("header_process_sbagcbd_pdcorpassumedficticiousnamecert"); if (control) control.setVisible(corpVisible);
		control = formContext.getControl("header_process_sbagcbd_pdcorpbylawsandanyamendment"); if (control) control.setVisible(corpVisible);
		control = formContext.getControl("header_process_sbagcbd_pdcorporatedocumentsmeetingminutes"); if (control) control.setVisible(corpVisible);
		control = formContext.getControl("header_process_sbagcbd_pdcorpstockledger"); if (control) control.setVisible(corpVisible);
		
		control = formContext.getControl("header_process_sbagcbd_pdllcarticlesoforganizationandanyamen"); if (control) control.setVisible(llcVisible);
		control = formContext.getControl("header_process_sbagcbd_pdllcmembersmeetingminutes"); if (control) control.setVisible(llcVisible);
		control = formContext.getControl("header_process_sbagcbd_pdllcoperatingagreementandanyamend"); if (control) control.setVisible(llcVisible);
		
		control = formContext.getControl("header_process_sbagcbd_pdparnershipassumedfictitiousnamecer"); if (control) control.setVisible(partnershipVisible);
		control = formContext.getControl("header_process_sbagcbd_pdpartnershipagreementandanyamendment"); if (control) control.setVisible(partnershipVisible);
		
		control = formContext.getControl("header_process_sbagcbd_pdsolepropassumedficticiousnamecertif"); if (control) control.setVisible(soleVisible);		
	}
	catch(err)
	{
		
	}
}

function checkDraft()
{
	debugger;
	var theAttribute;
	var value=true;
	
	var businessType = formContext.getAttribute("sbagcbd_confirmedbusinesstype").getValue();

	var stepsCollection = formContext.data.process.getActiveStage().getSteps();
	stepsCollection.forEach(
		function(step, index) {
			var attribute = step.getAttribute();
			if(attribute != "sbagcbd_prescreenphasestatus" && attribute != "sbagcbd_prescreenstatusnotes")
			{
				if(formContext.getAttribute(attribute) != null)
				{ 
					if(formContext.getAttribute(attribute).getValue() == null || formContext.getAttribute(attribute).getValue() == false)
					{
						value=false;
					}
				}
			}
		}
	);
	return value;
}

function checkPrescreen()
{
	debugger;
	var theAttribute;
	var value=true;
	
	var businessType = formContext.getAttribute("sbagcbd_confirmedbusinesstype").getValue();

	var stepsCollection = formContext.data.process.getActiveStage().getSteps();
	stepsCollection.forEach(
		function(step, index) {
			var attribute = step.getAttribute();
			if(attribute != "sbagcbd_prescreenphasestatus" && attribute != "sbagcbd_prescreenstatusnotes")
			{
				if(formContext.getAttribute(attribute) != null)
				{ 
					if(formContext.getAttribute(attribute).getValue() == null || formContext.getAttribute(attribute).getValue() == false)
					{
						value=false;
					}
				}
			}
		}
	);
	return value;
}

function checkScreen()
{
	debugger;
	var theAttribute;
	var value=true;
	
	showHideScreenFields();
	var businessType = formContext.getAttribute("sbagcbd_confirmedbusinesstype").getValue();

	var stepsCollection = formContext.data.process.getActiveStage().getSteps();
	stepsCollection.forEach(
		function(step, index) {
			var attribute = step.getAttribute();
			if(attribute != "sbagcbd_screen_phase_status" && attribute != "sbagcbd_screenstatusnotes")
			{
				if(formContext.getAttribute(attribute) != null)
				{ 
					if(formContext.getAttribute(attribute).getValue() == null || formContext.getAttribute(attribute).getValue() == false)
					{
						value=false;
					}
				}
			}
		}
	);
	return value;
}

function checkProcess()
{
	debugger;
	var theAttribute;
	var value=true;
	
	var businessType = formContext.getAttribute("sbagcbd_confirmedbusinesstype").getValue();

	var stepsCollection = formContext.data.process.getActiveStage().getSteps();
	stepsCollection.forEach(
		function(step, index) {
			var attribute = step.getAttribute();
			if(attribute != "sbagcbd_processing_phase_status" && attribute != "sbagcbd_processstatusnotes")
			{
				if(formContext.getAttribute(attribute) != null)
				{ 
					if(formContext.getAttribute(attribute).getValue() == null || formContext.getAttribute(attribute).getValue() == false)
					{
						value=false;
					}
				}
			}
		}
	);
	return value;
}

function checkSupervisor()
{
	debugger;
	var theAttribute;
	var value=true;
	
	var businessType = formContext.getAttribute("sbagcbd_confirmedbusinesstype").getValue();

	var stepsCollection = formContext.data.process.getActiveStage().getSteps();
	stepsCollection.forEach(
		function(step, index) {
			var attribute = step.getAttribute();
			if(attribute != "sbagcbd_supervisor_review_status" && attribute != "sbagcbd_supervisorstatusnotes")
			{
				if(formContext.getAttribute(attribute) != null)
				{ 
					if(formContext.getAttribute(attribute).getValue() == null || formContext.getAttribute(attribute).getValue() == false)
					{
						value=false;
					}
				}
			}
		}
	);
	return value;
}

function checkPD()
{
	debugger;
	var theAttribute;
	var value=true;
	
	var businessType = formContext.getAttribute("sbagcbd_confirmedbusinesstype").getValue();

	var stepsCollection = formContext.data.process.getActiveStage().getSteps();
	stepsCollection.forEach(
		function(step, index) {
			var attribute = step.getAttribute();
			if(attribute != "sbagcbd_pd_review_stage_status" && attribute != "sbagcbd_pdstatusnotes" && attribute != "sbagcbd_processing_phase_status")
			{
				if(formContext.getAttribute(attribute) != null)
				{ 
					if(formContext.getAttribute(attribute).getValue() == null || formContext.getAttribute(attribute).getValue() == false)
					{
						value=false;
					}
				}
			}
		}
	);
	return value;
}

function checkForOpenReferrals()
{
	debugger;
	var caseGUID = Xrm.Page.data.entity.getId(); 
	try
	{
		var fetchXmlQuery = null;
		var results = null;
		var newResults = [];
		var returnValue = false;
		fetchXmlQuery = '<fetch><entity name="sbagcbd_review"><all-attributes/><filter type="and"><condition attribute="regardingobjectid" operator="eq" value="' + caseGUID + '"/><condition attribute="sbagcbd_reviewstatus" operator="in"><value>517220006</value><value>517220007</value><value>517220008</value><value>517220009</value></condition></filter></entity></fetch>';
		
		if(fetchXmlQuery != null)
		{
			var globalContext = Xrm.Utility.getGlobalContext();
			var req = new XMLHttpRequest();  
			req.open(  
			  "GET",  
			  globalContext.getClientUrl() +  "/api/data/v9.0/sbagcbd_reviews?fetchXml=" +  encodeURIComponent(fetchXmlQuery),  
			  true  
			);  
			req.setRequestHeader("Prefer", 'odata.include-annotations="*"');  
			req.onreadystatechange = function() {  
			  if (this.readyState === 4) {  
				req.onreadystatechange = null;  
				if (this.status === 200) {  
					//
					results = JSON.parse(this.response);
					if(results.value.length > 0)
					{
						returnValue = true;
					}
				} else {  
				}  
			  }  
			};  
			req.send();   
		}		
	}
	catch (err)
	{
	}
	return returnValue;
}

function setOptionSet(fieldName, setText) {
	try
	{
		var control = formContext.getAttribute(fieldName);

		if (control.getAttributeType() == 'optionset') {
			if (setText == "" || setText == null || setText == undefined) {
				control.setValue(null);
			}
			else {
				var controlOpts = control.getOptions();
				for (var i = 0; i <= controlOpts.length - 1; i++) {
					if (controlOpts[i].text.toLowerCase() == setText.toLowerCase()) {
						control.setValue(controlOpts[i].value);
						return ;
					}
				}
			}
		}
	}
	catch (err)
	{
	}
}

function setBoolean(fieldName, value) {
	try
	{
		var control = formContext.getAttribute(fieldName);

		if (control.getAttributeType() == 'boolean') {
			control.setValue(value);
		}
	}
	catch (err)
	{
	}
}

function calculate8a()
{
	var cert8a = false;
	var is8a;
	var field = formContext.getAttribute("sbagcbd_iscertifiedbysba");
	if(field == null)
	{
		return false;
	}
	else
	{
		is8a = field.getValue();
	}
	if(is8a == 517220000)
		cert8a = true;
	return cert8a;
}

function calculateTPC()
{
	var certTPC = false;
	var isTPC;
	var field = formContext.getAttribute("sbagcbd_isapplicantcertifieaswosbedwosbbt");
	if(field == null)
	{
		return false;
	}
	else
	{
		isTPC = field.getValue();
	}
	if(isTPC == 517220000)
		certTPC = true;
	return certTPC;
}

function calculateCVE()
{
	var certCVE = false;
	var isCVE;
	var field = formContext.getAttribute("sbagcbd_iscertifiedbysdvosb");
	if(field == null)
	{
		return false;
	}
	else
	{
		isCVE = field.getValue();
	}	
	if(isCVE == 517220000)
		certCVE = true;
	return certCVE;
}