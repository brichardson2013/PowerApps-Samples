function AddOnStageChange()
{
	var bpfValue = formContext.getAttribute("sbagcbd_bpf").getValue();
	var materialchange = formContext.getAttribute("sbagcbd_materialchangeinitiated"),getValue();
	if(bpfValue != null) // we're in a BPF other than the default
	{
		switch(bpfValue[0].name)
		{
			case "Certify BPF FINAL Decert":
				return;
			case "Certify BPF Proposed Decert":
				return;
			default:
				return;
		}
	}