function processParameters(executionContext) {
	try 
	{
		debugger
		var formContext = executionContext.getFormContext();
		var caseGUID = formContext.data.attributes.get("case_id").getValue();
		var cardName = formContext.data.attributes.get("card_name").getValue();
		var sectionName = formContext.data.attributes.get("section_name").getValue();
		var icsectionName = formContext.data.attributes.get("icsection_name").getValue();	
		var review = formContext.data.attributes.get("review_name").getValue();
		var ic = formContext.data.attributes.get("individual_contributor").getValue();
		var infoArea = formContext.data.attributes.get("area_name").getValue();
		var stageObject = formContext.data.attributes.get("stage_name");
		var stage;
		if(stageObject != null)
		{
			stage = stageObject.getValue();
		}	
		var cardId = null;
		var sectionId = null;
		
		if(caseGUID != null && (cardName != null || infoArea != null)) {
			var reviewStatus = Xrm.Page.ui.controls.get("sbagcbd_reviewstatus");
			reviewStatus.removeOption(517220006);
			reviewStatus.removeOption(517220007);
			reviewStatus.removeOption(517220008);			
			reviewStatus.removeOption(517220009);	
			if(infoArea != null)
			{
				var tabObj = Xrm.Page.ui.tabs.get("General");
				var sectionObj = tabObj.sections.get("IndividualContributors");	
				sectionObj.setVisible(false);				
			}
			//Xrm.Page.getAttribute("sbagcbd_reviewstatus").setValue(517220000);			

		}
		else if(caseGUID != null && cardName == null)
		{
			var reviewStatus = Xrm.Page.ui.controls.get("sbagcbd_reviewstatus");
			Xrm.Page.getAttribute("sbagcbd_reviewstatus").setRequiredLevel("required");
			reviewStatus.removeOption(517220000);
			reviewStatus.removeOption(517220001);
			reviewStatus.removeOption(517220002);
			if(stage != "Final Approval" && stage != "Examination Of A Concern - Process" && stage != "Examination Of A Concern - Supervisor Review" && stage != "Examination Of A Concern - PD Review")
			{
				reviewStatus.removeOption(517220008);			
				reviewStatus.removeOption(517220009);				
			}				
			reviewStatus.removeOption(517220003);
			reviewStatus.removeOption(517220004);
			reviewStatus.removeOption(517220005);
			//Xrm.Page.getAttribute("sbagcbd_reviewstatus").setValue(517220007);			
		}
		
		if(cardName != null && cardName.includes("Individual"))
		{
			Xrm.Page.getAttribute("sbagcbd_individualcontributor").setRequiredLevel("required");
			Xrm.Page.getAttribute("sbagcbd_individualcontribsection").setRequiredLevel("required");
		}
		else
		{
			// hide Individual Contributor section
			var tabObj = Xrm.Page.ui.tabs.get("General");
			var sectionObj = tabObj.sections.get("IndividualContributors");
	
			sectionObj.setVisible(false);
		}
		
		if (caseGUID !== null) // sample code for getting non-entity bound data  
		{  
			var lookup = [];
			lookup[0] = {};
			lookup[0].id = caseGUID;
			lookup[0].entityType = "incident";	
			lookup[0].name = "incident";
			Xrm.Page.getAttribute("regardingobjectid").setValue(lookup);
		} 
		
		if(ic != null)
		{
			setIC(ic);
		}
		
		if(review != null)
		{
			if(review == "Needs Information")
				Xrm.Page.getAttribute("sbagcbd_reviewstatus").setValue(517220003);
		}
		
		if(infoArea != null)
		{
			Xrm.Page.getAttribute("sbagcbd_area").setValue(infoArea);
		}
		
		if(cardName != null)
		{
			var fetchXmlQuery = '<fetch><entity name="sbagcbd_casecard"><all-attributes/><filter type="and"><condition attribute="sbagcbd_name" operator="eq" value="' + cardName + '"/><condition attribute="sbagcbd_casecardincident" operator="eq" value="' + caseGUID + '"/></filter></entity></fetch>';
			if(fetchXmlQuery != null)
			{
				var globalContext = Xrm.Utility.getGlobalContext();
				var req = new XMLHttpRequest();  
				req.open(  
				  "GET",  
				  globalContext.getClientUrl() +  "/api/data/v9.0/sbagcbd_casecards?fetchXml=" +  encodeURIComponent(fetchXmlQuery),  
				  true  
				);  
				req.setRequestHeader("Prefer", 'odata.include-annotations="*"');  
				req.onreadystatechange = function() {  
				  if (this.readyState === 4) {  
					req.onreadystatechange = null;  
					if (this.status === 200) {  
						results = JSON.parse(this.response);
						cardId = results.value[0]["sbagcbd_casecardid"];
						if(cardId !== null)
						{
							var lookup = [];
							lookup[0] = {};        
							lookup[0].id = cardId;
							lookup[0].entityType = "sbagcbd_casecard";
							lookup[0].name = cardName;
							Xrm.Page.getAttribute("sbagcbd_card").setValue(lookup);
							getSection(formContext, caseGUID, sectionName);
							if(icsectionName != null)
							{
								getICSection("sbagcbd_individualcontribsection", icsectionName);
							}
						}
					} else {  }  
				  }
				};  
				req.send();   
			}
		}

	}
	catch { }
}	

function getSection(formContext, caseGUID, sectionName) {
	var fetch = '<fetch returntotalrecordcount="true"><entity name="sbagcbd_casecardsublevel1"><all-attributes/><filter type="and"><condition attribute="sbagcbd_name" operator="eq" value="' + sectionName + '"/><condition attribute="sbagcbd_incidentsublevel1" operator="eq" value="' + caseGUID + '"/></filter></entity></fetch>'
	if(fetch != null)
	{
		var globalContext = Xrm.Utility.getGlobalContext();
		var req = new XMLHttpRequest();  
		req.open(  
		  "GET",
		  globalContext.getClientUrl() +  "/api/data/v9.0/sbagcbd_casecardsublevel1s?fetchXml=" +  encodeURIComponent(fetch),  
		  true  
		);  
		req.setRequestHeader("Prefer", 'odata.include-annotations="*"');  
		req.onreadystatechange = function() {  
		  if (this.readyState === 4) {  
			req.onreadystatechange = null;  
			if (this.status === 200) {  
				results = JSON.parse(this.response);
				sectionId = results.value[0]["sbagcbd_casecardsublevel1id"];
				if(sectionId !== null)
				{
					var lookup = [];
					lookup[0] = {};        
					lookup[0].id = sectionId;
					lookup[0].entityType = "sbagcbd_casecardsublevel1";
					lookup[0].name = sectionName;
					Xrm.Page.getAttribute("sbagcbd_subsection").setValue(lookup);
				}					
			} else { }  
		  }  
		};  
		req.send();   
	}
}

function getICSection(fieldName, setText) {
	var fetch = '<fetch><entity name="sbagcbd_individualcontributorssection"><all-attributes/><filter type="and"><condition attribute="sbagcbd_name" operator="like" value="' + setText + '"/></filter></entity></fetch>'
	if(fetch != null)
	{
		var globalContext = Xrm.Utility.getGlobalContext();
		var req = new XMLHttpRequest();  
		req.open(  
		  "GET",
		  globalContext.getClientUrl() +  "/api/data/v9.0/sbagcbd_individualcontributorssections?fetchXml=" +  encodeURIComponent(fetch),  
		  true  
		);  
		req.setRequestHeader("Prefer", 'odata.include-annotations="*"');  
		req.onreadystatechange = function() {  
		  if (this.readyState === 4) {  
			req.onreadystatechange = null;  
			if (this.status === 200) {  
				results = JSON.parse(this.response);
				sectionId = results.value[0]["sbagcbd_individualcontributorssectionid"];	
				if(sectionId !== null)
				{
					var lookup = [];
					lookup[0] = {};        
					lookup[0].id = sectionId;
					lookup[0].entityType = "sbagcbd_individualcontributorssection";
					lookup[0].name = setText;
					Xrm.Page.getAttribute(fieldName).setValue(lookup);
				}					
			} else { }  
		  }  
		};  
		req.send();   
	}
}

function setIC(IC) {
	var fetch = '<fetch><entity name="sbagcbd_individualcontbr"><all-attributes/><filter type="and"><condition attribute="sbagcbd_fullname" operator="eq" value="' + IC + '"/></filter></entity></fetch>'
	if(fetch != null)
	{
		var globalContext = Xrm.Utility.getGlobalContext();
		var req = new XMLHttpRequest();  
		req.open(  
		  "GET",
		  globalContext.getClientUrl() +  "/api/data/v9.0/sbagcbd_individualcontbrs?fetchXml=" +  encodeURIComponent(fetch),  
		  true  
		);  
		req.setRequestHeader("Prefer", 'odata.include-annotations="*"');  
		req.onreadystatechange = function() {  
		  if (this.readyState === 4) {  
			req.onreadystatechange = null;  
			if (this.status === 200) {  
				results = JSON.parse(this.response);
				sectionId = results.value[0]["sbagcbd_individualcontbrid"];	
				if(sectionId !== null)
				{
					var lookup = [];
					lookup[0] = {};        
					lookup[0].id = sectionId;
					lookup[0].entityType = "sbagcbd_individualcontbr";
					lookup[0].name = IC;
					Xrm.Page.getAttribute("sbagcbd_individualcontributor").setValue(lookup);
				}					
			} else { }  
		  }  
		};  
		req.send();   
	}
}

