function loadReviewForm()
{
	debugger;
	
	//var formContext = executionContext.getFormContext();
	var reviewType = Xrm.Page.getAttribute("sbagcbd_reviewstatus");
	var notifyFirm = Xrm.Page.getAttribute("sbagcbd_notifyfirm").getValue();

	if(reviewType != null)
	{

		Xrm.Page.getAttribute("sbagcbd_reviewstatus").addOnChange(onChangeReviewStatus);
		Xrm.Page.getAttribute("sbagcbd_rfiduedate").addOnChange(onChangeRFIDueDate);
		Xrm.Page.getAttribute("sbagcbd_reasonforreview").addOnChange(onChangeEOCReason);
		Xrm.Page.getAttribute("sbagcbd_oocreasonforreview").addOnChange(onChangeOOCReason);	
		Xrm.Page.getControl("sbagcbd_otherreferral").setVisible(false);
		Xrm.Page.getControl("sbagcbd_materialchange").setVisible(false);		
		if(notifyFirm != null)
		{
			Xrm.Page.getAttribute("sbagcbd_notifyfirm").addOnChange(onChangeNotifyFirm);
		}
		typeText = reviewType.getValue();
		
		if(typeText == 517220003) {
			Xrm.Page.getAttribute("sbagcbd_rfiduedateextensionreason").setRequiredLevel("none");			
			Xrm.Page.getControl("sbagcbd_rfiduedateextensionreason").setVisible(false);			
		}
		

/* 		if(typeText == 517220006 || typeText == 517220007)
		{
			hideShowFields(false);			
		} */
		if(typeText == 517220001 || typeText == 517220006 || typeText == 517220007 || typeText == 517220008 || typeText == 517220009)
		{
			Xrm.Page.getAttribute("sbagcbd_rfiduedateextensionreason").setRequiredLevel("none");			
			Xrm.Page.getControl("sbagcbd_rfiduedateextensionreason").setVisible(false);
			hideShowFields(false);					
			onChangeEOCReason();
			onChangeOOCReason();
		}
		else
		{
			hideShowFields(true);
			if(notifyFirm == true)
			{
				Xrm.Page.getAttribute("sbagcbd_externalnotes").setRequiredLevel("required");
			}
			else
			{
				Xrm.Page.getAttribute("sbagcbd_externalnotes").setRequiredLevel("none");
			}
		}
		var thisGUID = Xrm.Page.data.entity.getId();
		if(thisGUID == "")
		{
			// This is a new record
			Xrm.Page.getControl("sbagcbd_rfiduedateextensionreason").setVisible(false);
		}
		else
		{
			if(typeText == 517220003) {
				Xrm.Page.getControl("sbagcbd_rfiduedateextensionreason").setVisible(true);
				Xrm.Page.getAttribute("sbagcbd_rfiduedateextensionreason").setRequiredLevel("required");			
			}
			if(typeText == 517220000 || typeText == 517220001 || typeText == 517220002 || typeText == 517220003 || typeText == 517220004 || typeText == 517220005)
			{
				var reviewStatus = Xrm.Page.ui.controls.get("sbagcbd_reviewstatus");
				reviewStatus.removeOption(517220006);
				reviewStatus.removeOption(517220007);
				reviewStatus.removeOption(517220008);			
				reviewStatus.removeOption(517220009);					
			}
			else
			{
				var reviewStatus = Xrm.Page.ui.controls.get("sbagcbd_reviewstatus");
				reviewStatus.removeOption(517220000);
				reviewStatus.removeOption(517220001);
				reviewStatus.removeOption(517220002);
				reviewStatus.removeOption(517220003);
				reviewStatus.removeOption(517220004);
				reviewStatus.removeOption(517220005);
			}			
		}
		
	}
}

function ShowHideIndividualContributors()
{
	try
	{
		debugger;
		
		var hasIndividualContributors = Xrm.Page.getAttribute("sbagcbd_hasindividualcontributors").getValue();
		var ic = Xrm.Page.getAttribute("sbagcbd_individualcontributor").getValue();
		
		var tabObj = Xrm.Page.ui.tabs.get("General");
		var sectionObj = tabObj.sections.get("IndividualContributors");
		
		if (hasIndividualContributors && ic != null)
		{
			sectionObj.setVisible(true);
		}
		else
		{
			sectionObj.setVisible(false);
		}
	}
	catch (err)
	{ }
}



function ShowHideRFISLAExtension()
{
	try
	{
		var ReviewStatus = Xrm.Page.getAttribute("sbagcbd_reviewstatus").getValue();
		var tabObj = Xrm.Page.ui.tabs.get("General");
		var sectionObj = tabObj.sections.get("Section_RFI_Due_Date");

		
		if(ReviewStatus == 517220003)
		{
			Xrm.Page.getAttribute("sbagcbd_rfiduedateextensionreason").setRequiredLevel("required");		
			sectionObj.setVisible(true);
		}
		else
		{
			Xrm.Page.getAttribute("sbagcbd_rfiduedateextensionreason").setRequiredLevel("none");		
			sectionObj.setVisible(false);
		}
	}
	catch (err)
	{ }
}


function makeRequired() {
	if ( document.readyState === "complete" || (document.readyState != "loading" && !document.documentElement.doScroll) )
	{
		setFieldsRequired();
	}
	else
	{
		document.addEventListener("DOMContentLoaded", setFieldsRequired);
	}
}

var setFieldsRequired = function() {
	var cardName = Xrm.Page.getAttribute("sbagcbd_card");
	if(cardName.getValue() != null)
	{
		var theCard = cardName.getValue()[0].name;
	
		if(theCard.includes("Individual"))
		{
			Xrm.Page.getAttribute("sbagcbd_individualcontributor").setRequiredLevel("required");
			Xrm.Page.getAttribute("sbagcbd_individualcontribsection").setRequiredLevel("required");
			Xrm.Page.getAttribute("sbagcbd_individualcontributorsubsection").setRequiredLevel("required");
		}
	}
}

function onChangeRFIDueDate()
{
	var rfiDueDate = Xrm.Page.getAttribute("sbagcbd_rfiduedate").getValue();
	if(rfiDueDate != null)
	{
		rfiDueDate = rfiDueDate.setHours(0,0,0,0);
		today = new Date();
		today = today.setHours(0,0,0,0);
		if(rfiDueDate < today)
		{
			Xrm.Page.getControl("sbagcbd_rfiduedate").setNotification("The RFI Due Date must be on or after today's date.");
		}
		else
		{
			Xrm.Page.getControl("sbagcbd_rfiduedate").clearNotification();
		}
	}
}

function hideShowFields(visible)
{
	var sizeStandards = false;
	var ogcReview = false;
	var oocReview = false;
	var eoc = false;
	var ic = false;
	var decertification = false;
	var rfi = false;
	var rfi_level = "none";
	var rfi_reason = false;
	var material_change = false;
	var typeText, reason;
	//Xrm.Page.getAttribute("sbagcbd_reviewstatus").addOnChange(onChangeReviewStatus);
	var reviewType = Xrm.Page.getAttribute("sbagcbd_reviewstatus");	
	var eocreason = Xrm.Page.getAttribute("sbagcbd_reasonforreview");
	if(reviewType != null)
	{
		typeText = reviewType.getValue();
	}
	if(eocreason != null) {
		reason = eocreason.getValue();
	}
	if(eocreason == 517220003) {
		material_change = true;
	}
	switch(typeText)
	{
		case 517220000:
			ic = true;
			break;
		case 517220001:
			ic = true;
			break;
		case 517220002:
			ic = true;
			break;
		case 517220003:
			var thisGUID = Xrm.Page.data.entity.getId();
			if(thisGUID != "")
			{
				rfi_level = "required";
				rfi_reason = true;
			}
			rfi = true;
			break;
		case 517220004:
			break;
		case 517220005:
			break;
		case 517220006:
			//Xrm.Page.getControl("sbagcbd_reviewstatus").setDisabled(true);
			sizeStandards = true;
			break;
		case 517220007:
			//Xrm.Page.getControl("sbagcbd_reviewstatus").setDisabled(true);
			ogcReview = true;
			break;			
		case 517220008:
			eoc = true;
			break;			
		case 517220009:
			oocReview = true;
			break;			
	}

	
	Xrm.Page.getAttribute("sbagcbd_rfiduedateextensionreason").setRequiredLevel(rfi_level);
	Xrm.Page.getControl("sbagcbd_rfiduedateextensionreason").setVisible(rfi_reason);	
	
	Xrm.Page.getControl("sbagcbd_card").setVisible(visible);	
	//Xrm.Page.getControl("sbagcbd_role").setVisible(visible);
	Xrm.Page.getControl("sbagcbd_subsection").setVisible(visible);
	Xrm.Page.getControl("sbagcbd_question").setVisible(visible);
	Xrm.Page.getControl("sbagcbd_stage").setVisible(visible);
	Xrm.Page.getControl("sbagcbd_notifyfirm").setVisible(visible);
	//Xrm.Page.getControl("sbagcbd_requestforinformation").setVisible(visible);
	Xrm.Page.ui.tabs.get("General").sections.get("Section_RFI_Due_Date").setVisible(rfi);
	Xrm.Page.ui.tabs.get("General").sections.get("IndividualContributors").setVisible(ic);	
	Xrm.Page.ui.tabs.get("General").sections.get("SizeStandards_section").setVisible(sizeStandards);	
	Xrm.Page.ui.tabs.get("General").sections.get("General_section_examofaconcern").setVisible(eoc);	
	Xrm.Page.ui.tabs.get("General").sections.get("General_section_material_change").setVisible(material_change);	
	Xrm.Page.ui.tabs.get("General").sections.get("section_Decertification").setVisible(decertification);	
	Xrm.Page.ui.tabs.get("General").sections.get("General_section_OGC_Review").setVisible(ogcReview);	
	Xrm.Page.ui.tabs.get("General").sections.get("General_section_OOC").setVisible(oocReview);	
	Xrm.Page.ui.tabs.get("General").sections.get("External_Notes").setVisible(visible);	
}
	

function onChangeReviewStatus()
{
	debugger;
	var reviewType = Xrm.Page.getAttribute("sbagcbd_reviewstatus");
	if(reviewType != null)
	{
		typeText = reviewType.getValue();
		if(typeText == 517220006 || typeText == 517220007 || typeText == 517220008 || typeText == 517220009)
		{
			Xrm.Page.getAttribute("sbagcbd_rfiduedateextensionreason").setRequiredLevel("none");			
			Xrm.Page.getControl("sbagcbd_rfiduedateextensionreason").setVisible(false);			
			hideShowFields(false);			
		}
		else if(typeText == 517220001)
		{
			Xrm.Page.getAttribute("sbagcbd_rfiduedateextensionreason").setRequiredLevel("none");			
			Xrm.Page.getControl("sbagcbd_rfiduedateextensionreason").setVisible(false);
		}
		else
		{
			var thisGUID = Xrm.Page.data.entity.getId();
			if(typeText == 517220003 && thisGUID == "")
			{
				Xrm.Page.getAttribute("sbagcbd_rfiduedateextensionreason").setRequiredLevel("none");			
				Xrm.Page.getControl("sbagcbd_rfiduedateextensionreason").setVisible(false);			
			}
			hideShowFields(true);
		}
	}	
	
}

function onChangeNotifyFirm()
{
	var notifyFirm = Xrm.Page.getAttribute("sbagcbd_notifyfirm").getValue();	
	if(notifyFirm == true)
	{
		Xrm.Page.getAttribute("sbagcbd_externalnotes").setRequiredLevel("required");
	}
	else
	{
		Xrm.Page.getAttribute("sbagcbd_externalnotes").setRequiredLevel("none");
	}
}

function onChangeEOCReason()
{
	var eocreason = Xrm.Page.getAttribute("sbagcbd_reasonforreview");
	Xrm.Page.getControl("sbagcbd_otherreferral").setVisible(false);
	Xrm.Page.getControl("sbagcbd_materialchange").setVisible(false);
	if(eocreason != null) {
		if(eocreason.getValue() == 517220003) { // Reported Material Change
			Xrm.Page.ui.tabs.get("General").sections.get("General_section_material_change").setVisible(true);	
			Xrm.Page.getControl("sbagcbd_materialchange").setVisible(true);			
		}
		else if(eocreason.getValue() == 517220002) { // Other Referral
			Xrm.Page.getControl("sbagcbd_otherreferral").setVisible(true);
		}
		else {
			Xrm.Page.ui.tabs.get("General").sections.get("General_section_material_change").setVisible(false);			
		}
	}

}

function onChangeOOCReason()
{
	var oocreason = Xrm.Page.getAttribute("sbagcbd_oocreasonforreview");
	if(oocreason != null) {
		if(oocreason.getValue() == 517220000) {
			Xrm.Page.ui.tabs.get("General").sections.get("General_section_material_change").setVisible(true);			
		}
		else {
			Xrm.Page.ui.tabs.get("General").sections.get("General_section_material_change").setVisible(false);			
		}
		if(oocreason.getValue() == 517220002 || oocreason.getValue() == 517220003 ) {
			Xrm.Page.ui.tabs.get("General").sections.get("General_section_annualUpdate").setVisible(true);			
		}
		else {
			Xrm.Page.ui.tabs.get("General").sections.get("General_section_annualUpdate").setVisible(false);			
		}		
	}

}

/// Show Documents subgrid on the main form
function setDocumentsIFrame(executionContext) {
    var formContext = executionContext.getFormContext();
    var tabName = "tab_documents";
    var iframeName = "IFRAME_documents";

    // Hide the tab until we're sure there's something to show
    var tab = formContext.ui.tabs.get(tabName);
    if (tab === null) {
        console.log("Could not find tab: " + tabName);
        return;
    }
    tab.setVisible(false);

    // Only want to run the code if the record is just being created, otherwise
    // there will no documents to show anyway
    if (formContext.ui.getFormType() !== 1) {
        var iframe = formContext.getControl(iframeName);
        if (iframe === null) {
            console.log("Could not find iframe: " + iframeName);
            return;
        }

        var id = formContext.data.entity.getId().replace("{", "").replace("}", "");

        // Query SharePoint Documents Locations to find any records which are related to the 
        // record we are currently viewing
        var req = new XMLHttpRequest();
        req.open("GET",
            formContext.context.getClientUrl() +
            "/api/data/v8.0/sharepointdocumentlocations?$select=_regardingobjectid_value&$filter=_regardingobjectid_value eq " +
            id, true);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"OData.Community.Display.V1.FormattedValue\"");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var results = JSON.parse(this.response);
                    if (results.value.length > 0) {
                        // If we have any related items then show the tab and set the IFrame URL accordingly
                        tab.setVisible(true);
                        var url = formContext.context.getClientUrl() +
                            "/userdefined/areas.aspx?formid=ab44efca-df12-432e-a74a-83de61c3f3e9&inlineEdit=1&navItemName=Documents&oId=%7b" +
                            formContext.data.entity.getId().replace("{", "").replace("}", "") +
                            "%7d&oType=" +
                            formContext.context.getQueryStringParameters().etc +
                            "&pagemode=iframe&rof=true&security=852023&tabSet=areaSPDocuments&theme=Outlook15White";
                        iframe.setSrc(url);
                    } else {
                        tab.setVisible(false);
                    }

                } else {
                    alert(this.statusText);
                }
            }
        };
        req.send();
    }
}

function ShowHideDecertification() {
}


