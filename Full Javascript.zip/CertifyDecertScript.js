function AddOnStageChange()
{
	debugger;
	Xrm.Page.data.process.addOnStageChange(manageStatuses);	

	var links = getLinks();

}

function getLinks()
{
	Xrm.Page.getControl("sbagcbd_bpf").setVisible(true);
	var bpfValue = Xrm.Page.getAttribute("sbagcbd_bpf").getValue();
	Xrm.Page.getControl("sbagcbd_bpf").setVisible(false);
	
	
	var caseGUID = Xrm.Page.data.entity.getId(); 
	var proposedletterlink = "";
	var finalletterlink = "";
	var fetchXmlQuery = '<fetch><entity name="sbagcbd_decertification"><all-attributes/><filter type="and"><condition attribute="sbagcbd_case" operator="eq" value="' + caseGUID + '"/></filter></entity></fetch>';
	if(fetchXmlQuery != null)
	{
		var globalContext = Xrm.Utility.getGlobalContext();
		var req = new XMLHttpRequest();  
		req.open(  
		  "GET",  
		  globalContext.getClientUrl() +  "/api/data/v9.0/sbagcbd_decertifications?fetchXml=" +  encodeURIComponent(fetchXmlQuery),  
		  true  
		);  
		req.setRequestHeader("Prefer", 'odata.include-annotations="*"');  
		req.onreadystatechange = function() {  
		  if (this.readyState === 4) {  
			req.onreadystatechange = null;  
			if (this.status === 200) {  
				results = JSON.parse(this.response);
				
				var proposedletterlink = results.value[0]["sbagcbd_proposeddecertletter"];
				if(proposedletterlink == null)
					proposedletterlink = "";
				var finalletterlink = results.value[0]["sbagcbd_decertletter"];
				if(finalletterlink == null)
					finalletterlink = "";
				
				var bpfValue = formContext.getAttribute("sbagcbd_bpf").getValue();
				//formContext.getControl("sbagcbd_bpf").setVisible(false);
				formContext.getControl("sbagcbd_materialchangeinitiated").setVisible(true);
				var materialchange = formContext.getAttribute("sbagcbd_materialchangeinitiated").getValue();
				formContext.getControl("sbagcbd_materialchangeinitiated").setVisible(false);
				var notificationToFirmTab = formContext.ui.tabs.get("tab_AppReviewSummary");
				var proposedSection = notificationToFirmTab.sections.get("tab_AppReviewSummary_section_ProposedDecert");
				var finalSection = notificationToFirmTab.sections.get("tab_AppReviewSummary_section_Final_Decert");

				if(bpfValue != null) // we're in a BPF other than the default
				{
					proposedSection.setVisible(false);
					finalSection.setVisible(false);
					var activeStage = formContext.data.process.getActiveStage();
					var stageName = "";
					if(activeStage != null)
						stageName = activeStage.getName();
					var control;
					
					switch(bpfValue[0].name)
					{
						case "Certify BPF Proposed Decert":
							if(materialchange)
							{	
								// show the proposed section
								proposedSection.setVisible(true);
							}
							switch(stageName.toLowerCase())
							{
								case "process proposed decertification":
									control = formContext.getControl("header_process_sbagcbd_proposeddecertprocessingstatus"); if(control) { control.setDisabled(false); }
									control = formContext.getControl("header_process_sbagcbd_proposeddecertprocessingstatus_1"); if(control) { control.setDisabled(false); }
									control = formContext.getControl("header_process_sbagcbd_proposeddecertsupervisorstatus"); if(control) { control.setDisabled(true); }
									control = formContext.getControl("header_process_sbagcbd_proposeddecertpdstatus"); if(control) { control.setDisabled(true); }
									break;
								case "supervisor review - proposed decert":
									control = formContext.getControl("header_process_sbagcbd_proposeddecertprocessingstatus"); if(control) { control.setDisabled(true); }
									control = formContext.getControl("header_process_sbagcbd_proposeddecertprocessingstatus_1"); if(control) { control.setDisabled(true); }
									control = formContext.getControl("header_process_sbagcbd_proposeddecertsupervisorstatus"); if(control) { control.setDisabled(false); }
									control = formContext.getControl("header_process_sbagcbd_proposeddecertpdstatus"); if(control) { control.setDisabled(true); }
									break;
								case "pd review - proposed decert":
									control = formContext.getControl("header_process_sbagcbd_proposeddecertprocessingstatus"); if(control) { control.setDisabled(true); }
									control = formContext.getControl("header_process_sbagcbd_proposeddecertprocessingstatus_1"); if(control) { control.setDisabled(true); }
									control = formContext.getControl("header_process_sbagcbd_proposeddecertsupervisorstatus"); if(control) { control.setDisabled(true); }
									control = formContext.getControl("header_process_sbagcbd_proposeddecertpdstatus"); if(control) { control.setDisabled(false); }
									break;
								case "20 day sla":
									control = formContext.getControl("header_process_sbagcbd_proposeddecertprocessingstatus"); if(control) { control.setDisabled(true); }
									control = formContext.getControl("header_process_sbagcbd_proposeddecertprocessingstatus_1"); if(control) { control.setDisabled(true); }
									control = formContext.getControl("header_process_sbagcbd_proposeddecertsupervisorstatus"); if(control) { control.setDisabled(true); }
									control = formContext.getControl("header_process_sbagcbd_proposeddecertpdstatus"); if(control) { control.setDisabled(true); }
									break;
							}			
							return;			
						case "Certify BPF FINAL Decert":		
							if(materialchange)
							{
								// show the final section
								proposedSection.setVisible(true);
								finalSection.setVisible(true);
							}	
							switch(stageName.toLowerCase())
							{
								case "process - final decert":
									control = formContext.getControl("header_process_sbagcbd_decertprocessstatus"); if(control) { control.setDisabled(false); }
									control = formContext.getControl("header_process_sbagcbd_decertsupervisorstatus"); if(control) { control.setDisabled(true); }
									control = formContext.getControl("header_process_sbagcbd_decertpdstatus"); if(control) { control.setDisabled(true); }
									break;
								case "supervisor review - final decert":
									control = formContext.getControl("header_process_sbagcbd_decertprocessstatus"); if(control) { control.setDisabled(true); }
									control = formContext.getControl("header_process_sbagcbd_decertsupervisorstatus"); if(control) { control.setDisabled(false); }
									control = formContext.getControl("header_process_sbagcbd_decertpdstatus"); if(control) { control.setDisabled(true); }
									break;
								case "pd review - final decert":
									control = formContext.getControl("header_process_sbagcbd_decertprocessstatus"); if(control) { control.setDisabled(true); }
									control = formContext.getControl("header_process_sbagcbd_decertsupervisorstatus"); if(control) { control.setDisabled(true); }
									control = formContext.getControl("header_process_sbagcbd_decertpdstatus"); if(control) { control.setDisabled(false); }
									break;
							}											
							return;
						default:
							if(proposedletterlink != null && proposedletterlink != "")
							{
								// this case has been through proposed, so show the section, but disable the fields
								proposedSection.setVisible(true);
							}
							else
							{
								// hide the proposed letter section
								proposedSection.setVisible(false);
							}
							if(finalletterlink != null && finalletterlink != "")
							{
								// this case has been through final decert, so show the section, but disable the fields
								finalSection.setVisible(true);
							}
							else
							{
								// hide the final decert section
								finalSection.setVisible(false);
							}				
							return;
					}
				}
				else
				{
					proposedSection.setVisible(false);
					finalSection.setVisible(false);

					if(proposedletterlink != null && proposedletterlink != "")
					{
						// this case has been through proposed, so show the section, but disable the fields
						proposedSection.setVisible(true);
					}
					else
					{
						// hide the proposed letter section
						proposedSection.setVisible(false);
					}
					if(finalletterlink != null && finalletterlink != "")
					{
						// this case has been through final decert, so show the section, but disable the fields
						finalSection.setVisible(true);
					}
					else
					{
						// hide the final decert section
						finalSection.setVisible(false);
					}				
				}
			} 	
			else 
			{ 
			}  
		  }
		};  
		req.send();   
	}
}
	
function manageStatuses(executionContext) 
{
	var activeStage = formContext.data.process.getActiveStage();
	var stageName = "";
	if(activeStage != null)
		stageName = activeStage.getName();
	var control;
	
	switch(stageName.toLowerCase())
	{
		case "process proposed decertification":
			control = formContext.getControl("header_process_sbagcbd_proposeddecertprocessingstatus"); if(control) { control.setDisabled(false); }
			control = formContext.getControl("header_process_sbagcbd_proposeddecertprocessingstatus_1"); if(control) { control.setDisabled(false); }
			control = formContext.getControl("header_process_sbagcbd_proposeddecertsupervisorstatus"); if(control) { control.setDisabled(true); }
			control = formContext.getControl("header_process_sbagcbd_proposeddecertpdstatus"); if(control) { control.setDisabled(true); }
			break;
		case "supervisor review - proposed decert":
			control = formContext.getControl("header_process_sbagcbd_proposeddecertprocessingstatus"); if(control) { control.setDisabled(true); }
			control = formContext.getControl("header_process_sbagcbd_proposeddecertprocessingstatus_1"); if(control) { control.setDisabled(true); }
			control = formContext.getControl("header_process_sbagcbd_proposeddecertsupervisorstatus"); if(control) { control.setDisabled(false); }
			control = formContext.getControl("header_process_sbagcbd_proposeddecertpdstatus"); if(control) { control.setDisabled(true); }
			break;
		case "pd review - proposed decert":
			control = formContext.getControl("header_process_sbagcbd_proposeddecertprocessingstatus"); if(control) { control.setDisabled(true); }
			control = formContext.getControl("header_process_sbagcbd_proposeddecertprocessingstatus_1"); if(control) { control.setDisabled(true); }
			control = formContext.getControl("header_process_sbagcbd_proposeddecertsupervisorstatus"); if(control) { control.setDisabled(true); }
			control = formContext.getControl("header_process_sbagcbd_proposeddecertpdstatus"); if(control) { control.setDisabled(false); }
			break;
		case "20 day sla":
			control = formContext.getControl("header_process_sbagcbd_proposeddecertprocessingstatus"); if(control) { control.setDisabled(true); }
			control = formContext.getControl("header_process_sbagcbd_proposeddecertprocessingstatus_1"); if(control) { control.setDisabled(true); }
			control = formContext.getControl("header_process_sbagcbd_proposeddecertsupervisorstatus"); if(control) { control.setDisabled(true); }
			control = formContext.getControl("header_process_sbagcbd_proposeddecertpdstatus"); if(control) { control.setDisabled(true); }
			break;
		case "process - final decert":
			control = formContext.getControl("header_process_sbagcbd_decertprocessstatus"); if(control) { control.setDisabled(false); }
			control = formContext.getControl("header_process_sbagcbd_decertsupervisorstatus"); if(control) { control.setDisabled(true); }
			control = formContext.getControl("header_process_sbagcbd_decertpdstatus"); if(control) { control.setDisabled(true); }
			break;
		case "supervisor review - final decert":
			control = formContext.getControl("header_process_sbagcbd_decertprocessstatus"); if(control) { control.setDisabled(true); }
			control = formContext.getControl("header_process_sbagcbd_decertsupervisorstatus"); if(control) { control.setDisabled(false); }
			control = formContext.getControl("header_process_sbagcbd_decertpdstatus"); if(control) { control.setDisabled(true); }
			break;
		case "pd review - final decert":
			control = formContext.getControl("header_process_sbagcbd_decertprocessstatus"); if(control) { control.setDisabled(true); }
			control = formContext.getControl("header_process_sbagcbd_decertsupervisorstatus"); if(control) { control.setDisabled(true); }
			control = formContext.getControl("header_process_sbagcbd_decertpdstatus"); if(control) { control.setDisabled(false); }
			break;
	}				
}
