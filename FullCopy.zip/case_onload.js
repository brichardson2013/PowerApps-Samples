var Sdk = window.Sdk || {};
(function () {
    // Define some global variables
	var reviews = null;
    var myUniqueId = "_myUniqueId"; // Define an ID for the notification
    var currentUserName = Xrm.Utility.getGlobalContext().userSettings.userName; // get current user name
    var message = currentUserName + ":  are you Ready?";
	


    // Code to run in the form OnLoad event
    this.formOnLoad = function (executionContext) {
		
        var formContext = executionContext.getFormContext();
		
		var caseType = null;
		var businessType = null;

		formContext.data.process.addOnStageChange(stageChange);

		
		if(formContext.getAttribute("casetypecode") != null) {
			caseType = formContext.getAttribute("casetypecode").getText();
			if(caseType != "EDWOSB")
				hideFinancialSections(executionContext);
		}
		
		if(formContext.getAttribute("sbagcbd_businesstype") != null) {
			var businessType = formContext.getAttribute("sbagcbd_businesstype").getText();
			if(businessType != null)
			{
				//showSummary_BusinessTypeSections(executionContext, businessType);
				hideReview_BusinessTypeSections(executionContext, businessType);
			}
		}
		
		var activeStage = formContext.data.process.getActiveStage().getName();
		var tab_analystreview = formContext.ui.tabs.get("tab_AnalystReview");
		
		switch(activeStage.toLowerCase())
		{
			case "supervisor review":
				tab_analystreview.setLabel("Supervisor Review");
				formContext.getControl("tab_AnalystReview_section_Drafts").setVisible(true);
				break;
			case "pd review":
				tab_analystreview.setLabel("PD Review");
				formContext.getControl("tab_AnalystReview_section_Drafts").setVisible(true);				
				break;
		}
			
		processAlerts(executionContext);
		processConditionalQuestions(executionContext);
		//showSections(executionContext);
		retrieveReviews(executionContext, formContext.data.entity.getId());
    }
	
	
	showSections = function(executionContext) {
		try
		{
			var section_ownership = true;
				var subsection_womanownership = true;
				var subsection_firmownership = true;
				var subsection_businessstructure = true;
			var section_other_certifications = true;
				var subsection_thirdparty = true;
				var subsection_cve = true;
			var section_control = true;
				var subsection_highestpositon = true;
				var subsection_fullcontrol = true;
			var section_individualcontributors = true;
				var subsection_financialdata = true;
			var section_economic_disadvantage = true;
				var subsection_networth = true;
				var subsection_adjustedgrossincome = true;
				var subsection_assets = true; 
				
			//showHideSections(executionContext, "WebResource_ownership_section_label", "WebResource_section_ownership_incomplete", section_ownership);
			showHideSections(executionContext, "WebResource_othercertificationsection", "WebResource_section_othercerts_incomplete", section_other_certifications);
				showHideSections(executionContext, "WebResource_businessstructurelabel", "WebResource_subsection_businesstructure_incomplete", subsection_businessstructure);
			showHideSections(executionContext, "WebResource_controllabel", "WebResource_section_control_incomplete", section_control);
			showHideSections(executionContext, "WebResource_individualcontributorssection", "WebResource_section_individcontrib_incomplete", section_individualcontributors);
			showHideSections(executionContext, "WebResource_economicdisadvantagelabel", "WebResource_section_economicdis_incomplete", section_economic_disadvantage);			
		}
		catch {}
	}

	showHideSections = function(executionContext, complete, incomplete, status) {
		try
		{
			//debugger
			var formContext = executionContext.getFormContext();
			if(status)
			{
				formContext.getControl(complete).setVisible(true);
				formContext.getControl(incomplete).setVisible(false);
			}
			else
			{
				formContext.getControl(incomplete).setVisible(true);
				formContext.getControl(complete).setVisible(false);
			}
		}
		catch {}
	}

	showSummary_BusinessTypeSections = function(executionContext, businessType) {
		try 
		{
			var formContext = executionContext.getFormContext();
			//debugger;
			switch(businessType.toLowerCase()) {
				case "partnership":
					//alert("Partnership");
					formContext.getControl("WebResource_subsectionl1_partner").setVisible(true);

					formContext.getControl("WebResource_question_partnership_51_eachclass").setVisible(true);
					formContext.getAttribute("sbagcbd_show51pofeachclass").setVisible(true);
					formContext.getAttribute("sbagcbd_show51pofeachclassnote").setVisible(true);

					formContext.getControl("WebResource_quetion_agreement_appserverasgp").setVisible(true);
					formContext.getAttribute("sbagcbd_showagrservegeneralpartners").setVisible(true);
					formContext.getAttribute("sbagcbd_showagrservegeneralpartnersnote").setVisible(true);
					
					formContext.getControl("WebResource_question_partner_fictitiousname").setVisible(true);
					formContext.getAttribute("sbagcbd_partnershipusefictitiousname").setVisible(true);
					formContext.getAttribute("sbagcbd_partnershipusefictitiousnamenote").setVisible(true);
					
					break;
				case "corporation":
					formContext.getControl("WebResource_subsectionl1_corp").setVisible(true);
					
					formContext.getControl("WebResource_question_corp_stockledgeshotappowns51").setVisible(true);
					formContext.getAttribute("sbagcbd_stockcertificatesshowown51p").setVisible(true);
					formContext.getAttribute("sbagcbd_stockcertificatesshowown51pnote").setVisible(true);
					
					formContext.getControl("WebResource_questoin_corp_havemorethanoneclass").setVisible(true);
					formContext.getAttribute("sbagcbd_corporationvotingstock").setVisible(true);
					
					formContext.getControl("WebResource_question_corp_showatleast51eachclass").setVisible(true);
					formContext.getAttribute("sbagcbd_corporationstockledgerpercentage").setVisible(true);
					
					formContext.getControl("WebResource_question_corp_didyouconsider").setVisible(true);
					formContext.getAttribute("sbagcbd_considerunexercisedstockoptions").setVisible(true);
					
					formContext.getControl("WebResource_question_corp_anyunexercised").setVisible(true);
					formContext.getAttribute("sbagcbd_anyunexercisedstockoptionsbyapp").setVisible(true);
					
					formContext.getControl("WebResource_question_corp_articlesshowappcontrolsboard").setVisible(true);
					formContext.getAttribute("sbagcbd_applcontrolboardofdirectors").setVisible(true);
					formContext.getAttribute("sbagcbd_applcontrolboardofdirectorsnote").setVisible(true);
					
					formContext.getControl("WebResource_question_corporation_fictitiousname").setVisible(true);
					formContext.getAttribute("sbagcbd_corporationusefictitiousname").setVisible(true);
					formContext.getAttribute("sbagcbd_corporationusefictitiousnamenote").setVisible(true);

					break;
				case "llc" :
					formContext.getControl("WebResource_subsectoinl1llc").setVisible(true);
					
					formContext.getControl("WebResource_question_llc_51pctofclass").setVisible(true);
					formContext.getAttribute("sbagcbd_isorgarticlesshow51intrst").setVisible(true);

					formContext.getControl("WebResource_question_llc_articleshsow_appmanagers").setVisible(true);	
					formContext.getAttribute("sbagcbd_servemanagementmembers").setVisible(true);				
					formContext.getAttribute("sbagcbd_articlesshowappservemanagementmembersnote").setVisible(true);			

					formContext.getControl("question_llc_fictname").setVisible(true);	
					formContext.getAttribute("sbagcbd_soleprtshipafictitiousname").setVisible(true);				
					formContext.getAttribute("sbagcbd_llcusefictitiousnamenote").setVisible(true);				
					break;
				case "sole proprietorship":
					formContext.getControl("WebResource_subsectionl1_soleprop").setVisible(true);
					
					formContext.getControl("WebResource_question_llc_solepropusesfict").setVisible(true);
					formContext.getAttribute("sbagcbd_llcusefictitiousname").setVisible(true);				
					formContext.getAttribute("sbagcbd_llcusefictitiousnamenote").setVisible(true);				
					break;
				default:
					formContext.getControl("WebResource_subsection_businessstructure").setVisible(false);
					hidePartnership();
					hideCorporation();
					hideLLC();
					hideSoleProprietorship();
					break;
			}
		}
		catch { }
	}
	
	userHasRole = function(executionContext, role) {
		//debugger
		var result = false;
		var formContext = executionContext.getFormContext();		
 		var currentUserRoles = Xrm.Utility.getGlobalContext().userSettings.roles;
		currentUserRoles.forEach(function(currentRole) {
			if(currentRole.name == role)
			{
				result = true;
			}
		});
		return result;
	}
	
	stageChange = function(executionContext) {
			
			//debugger
			var formContext = executionContext.getFormContext();
			var activeStage = formContext.data.process.getActiveStage().getName();
			var tab_SBANotes = formContext.ui.tabs.get("tab_SBANotes");
			var tab_analystreview = formContext.ui.tabs.get("tab_AnalystReview");
			tab_SBANotes.setVisible(true);
			
			try
			{
				switch(activeStage.toLowerCase())
				{
					case "final approval":
						tab_SBANotes.setVisible(false);
						break;
					case "supervisor review":
						tab_AnalystReview.setLabel("Supervisor Review");
						break;
					case "pd review":
						tab_AnalystReview.setLabel("PD Review");				
						break;
				}
			}
			catch {}
	}

	hideFinancialSections = function(executionContext) {
		try
		{
		 var formContext = executionContext.getFormContext();
		 
		 var tabLongForm = formContext.ui.tabs.get("tab_appsummarylongform");
		 var tabAnalystReview = formContext.ui.tabs.get("tabAppReview");
		 
		 var sectionLongForm_FinancialData = formContext.getControl("WebResource_subsection_financialdata").setVisible(false);
		 var sectionLongForm_FinancialDataSubGrid = formContext.getControl("subgrid_financialdata").setVisible(false);

		 var sectionAnalysis_FinancialData = formContext.getControl("WebResource_financiallabel").setVisible(false);
		 var sectionAnalysis_FinancialDataSubGrid = formContext.getControl("financialdata_subgrid").setVisible(false);
		}
		catch { }
	}
	
	hideReview_BusinessTypeSections = function(executionContext, businessType) {
		try 
		{
			debugger
			var formContext = executionContext.getFormContext();
			if(businessType != null && businessType != " ")
			{
				switch(businessType.toLowerCase()) {
					case "partnership":
						hideCorporation(executionContext);
						hideLLC(executionContext);
						hideSoleProprietorship(executionContext);
						break;
					case "corporation":
						hidePartnership(executionContext);
						hideLLC(executionContext);
						hideSoleProprietorship(executionContext);				
						break;
					case "llc" :
						hidePartnership(executionContext);
						hideCorporation(executionContext);
						hideSoleProprietorship(executionContext);							
						break;
					case "sole proprietorship":
						hidePartnership(executionContext);
						hideCorporation(executionContext);
						hideLLC(executionContext);							
						break;
					default:
						formContext.getControl("WebResource_subsection_businessstructure").setVisible(false);	
						hidePartnership(executionContext);
						hideCorporation(executionContext);
						hideLLC(executionContext);	
						hideSoleProprietorship(executionContext);
				}
			}
			else
			{
				formContext.getControl("WebResource_subsection_businessstructure").setVisible(false);	
				hidePartnership(executionContext);
				hideCorporation(executionContext);
				hideLLC(executionContext);	
				hideSoleProprietorship(executionContext);
			}
		}
		catch { }
	}
	
	hidePartnership = function(executionContext) {
		try
		{
			var formContext = executionContext.getFormContext();	
			formContext.ui.tabs.get("tab_AnalystReview").sections.get("tab_AnalystReview_section_Partnership").setVisible(false);
			
/*			formContext.getControl("tab_AnalystReview_section_Partnership").setVisible(false);			
 			formContext.getControl("WebResource_subsectionl1_partnership").setVisible(false);

			formContext.getControl("WebResource_question_partnershipagreement_eachclass").setVisible(false);
			formContext.getControl("sbagcbd_show51pofeachclass").setVisible(false);
			formContext.getControl("sbagcbd_show51pofeachclassnote").setVisible(false);

			formContext.getControl("WebResource_question_partnershpagreement_generalpartners").setVisible(false);
			formContext.getControl("sbagcbd_showagrservegeneralpartners").setVisible(false);
			formContext.getControl("sbagcbd_showagrservegeneralpartnersnote").setVisible(false);
			
			formContext.getControl("WebResource_question_partnership_fictitiousname").setVisible(false);
			formContext.getControl("sbagcbd_partnershipusefictitiousname").setVisible(false);
			formContext.getControl("sbagcbd_partnershipusefictitiousnamenote").setVisible(false); */				
		}
		catch { }
	}
	
	hideCorporation = function(executionContext) {
		try
		{
			debugger
			var formContext = executionContext.getFormContext();
			formContext.ui.tabs.get("tab_AnalystReview").sections.get("tab_AnalystReview_section_corporation").setVisible(false);

/*			formContext.getControl("tab_AnalystReview_section_corporation").setVisible(false);
			formContext.getControl("WebResource_subsectionl1_corporation").setVisible(false);
 			formContext.getControl("WebResource_question_corporationappowns51percent").setVisible(false);
			formContext.getControl("sbagcbd_stockcertificatesshowown51p").setVisible(false);
			formContext.getControl("sbagcbd_stockcertificatesshowown51pnote").setVisible(false);
			
			formContext.getControl("WebResource_question_corporationmorethanoneclass").setVisible(false);
			formContext.getControl("sbagcbd_corporationvotingstock").setVisible(false);
			
			formContext.getControl("WebResource_question_corporationatleast50percentowned").setVisible(false);
			formContext.getControl("sbagcbd_corporationstockledgerpercentage").setVisible(false);
			
			formContext.getControl("WebResource_question_corporationconsideredunexercisedstockoptions").setVisible(false);
			formContext.getControl("sbagcbd_considerunexercisedstockoptions").setVisible(false);
			
			formContext.getControl("WebResource_question_corporationunexcercisedstockoptions").setVisible(false);
			formContext.getControl("sbagcbd_anyunexercisedstockoptionsbyapp").setVisible(false);
			
			formContext.getControl("WebResource_question_corporationappcontrolsboard").setVisible(false);
			formContext.getControl("sbagcbd_applcontrolboardofdirectors").setVisible(false);
			formContext.getControl("sbagcbd_applcontrolboardofdirectorsnote").setVisible(false);
			
			formContext.getControl("WebResource_question_corporationfictitiousname").setVisible(false);
			formContext.getControl("sbagcbd_corporationusefictitiousname").setVisible(false);
			formContext.getControl("sbagcbd_corporationusefictitiousnamenote").setVisible(false);	 */		
		}
		catch { }
	}
	
	hideLLC = function(executionContext) {
		try
		{
			var formContext = executionContext.getFormContext();
			formContext.ui.tabs.get("tab_AnalystReview").sections.get("tab_AnalystReview_section_llc").setVisible(false);

/*			formContext.getControl("tab_AnalystReview_section_llc").setVisible(false);
 			formContext.getControl("WebResource_subsectionl1_llc").setVisible(false);
			
			formContext.getControl("WebResource_question_llc51percentinterest").setVisible(false);
			formContext.getControl("sbagcbd_isorgarticlesshow51intrst").setVisible(false);

			formContext.getControl("WebResource_question_llcmanagmentmembers").setVisible(false);	
			formContext.getControl("sbagcbd_servemanagementmembers").setVisible(false);				
			formContext.getControl("sbagcbd_articlesshowappservemanagementmembersnote").setVisible(false);			

			formContext.getControl("WebResource_question_llcfictitiousname").setVisible(false);	
			formContext.getControl("sbagcbd_llcusefictitiousname").setVisible(false);				
			formContext.getControl("sbagcbd_llcusefictitiousnamenote").setVisible(false); */				
		}
		catch { }
	}
	
	hideSoleProprietorship = function(executionContext)	{
		try
		{
			var formContext = executionContext.getFormContext();
			formContext.ui.tabs.get("tab_AnalystReview").sections.get("tab_AnalystReview_section_soleproprietorship").setVisible(false);
			
/*			formContext.getControl("tab_AnalystReview_section_soleproprietorship").setVisible(false);
 			formContext.getControl("WebResource_subsectionl1_soleproprietor").setVisible(false);
			
			formContext.getControl("WebResource_question_sole_usefictitiousname").setVisible(false);
			formContext.getControl("sbagcbd_soleprtshipafictitiousname").setVisible(false);		 */			
		}
		catch { }
	}	
	
	retrieveReviews = function(executionContext, caseGUID)	{
		var fetchXmlQuery = null;
		var results = null;
		fetchXmlQuery = "<fetch returntotalrecordcount='true'><entity name='sbagcbd_review' ><all-attributes/><filter type='and' ><condition attribute='regardingobjectid' operator='eq' value='" + caseGUID + "' /><condition attribute='sbagcbd_reviewstatus' operator='neq' value='517220001' /></filter></entity></fetch>";
		
		if(fetchXmlQuery != null)
		{
			var globalContext = Xrm.Utility.getGlobalContext();
			var req = new XMLHttpRequest();  
			req.open(  
			  "GET",  
			  globalContext.getClientUrl() +  "/api/data/v9.0/sbagcbd_reviews?fetchXml=" +  encodeURIComponent(fetchXmlQuery),  
			  true  
			);  
			req.setRequestHeader("Prefer", 'odata.include-annotations="*"');  
			req.onreadystatechange = function() {  
			  if (this.readyState === 4) {  
				req.onreadystatechange = null;  
				if (this.status === 200) {  
					//debugger
					results = JSON.parse(this.response);  
					processAllFlags(executionContext, results);
				} else {  
					//debugger
					//alert(this.responseText);  
					return "";
				}  
			  }  
			};  
			req.send();   
		}
	}
	
	processAllFlags = function(executionContext, results) {
		try
		{
			var flagObjects = {
				ownership:{value:0,womenownership:0,firmownership:0,businessstructure: {value:0, partnership:0, llc:0, corporation:0, soleproprietorship:0}},
				othercertifications:{value:0,thirdparty:0,cve:0},
				control:{value:0,highestposition:0,fullcontrol:0},
				individualcontributor:{value:0,financialdata:0},
				economicdisadvantage:{value:0,networth:0,adjustedgrossincome:0,assets:0}
			};

			//debugger
			results.value.forEach(function(review) {
				
				if(review["_sbagcbd_subsection_value@OData.Community.Display.V1.FormattedValue"] != null)
				{
					switch(review["_sbagcbd_subsection_value@OData.Community.Display.V1.FormattedValue"].toLowerCase()) {
						case "women ownership":
							flagObjects.ownership.womenownership += 1;
							break;
						case "firm ownership":
							flagObjects.ownership.firmownership += 1;
							break;
						case "business structure":
							flagObjects.ownership.businessstructure.value += 1;
							break;
						case "third party":
							flagObjects.othercertifications.thirdparty += 1;
							break;
						case "cve":
							flagObjects.othercertifications.cve += 1;
							break;
						case "highest position":
							flagObjects.control.highestposition += 1;
							break;	
						case "full control":
							flagObjects.control.fullcontrol += 1;
							break;	
						case "financial data":
							flagObjects.individualcontributor.financialdata += 1;
							break;	
						case "networth":
							flagObjects.economicdisadvantage.networth += 1;
							break;	
						case "adjusted gross income":
							flagObjects.economicdisadvantage.adjustedgrossincome += 1;
							break;	
						case "assets":
							flagObjects.economicdisadvantage.assets += 1;
							break;						
					}; 				
				}

				if(review["_sbagcbd_card_value@OData.Community.Display.V1.FormattedValue"] != null)
				{
					switch(review["_sbagcbd_card_value@OData.Community.Display.V1.FormattedValue"].toLowerCase()) {
						case "ownership":
							flagObjects.ownership.value += 1;
							break;
						case "other certifications":
							flagObjects.othercertifications.value += 1;
							break;
						case "control":
							flagObjects.control.value += 1;
							break;
						case "individual contributors":
							flagObjects.individualcontributor.value += 1;
							break;
						case "economic disadvantage":
							flagObjects.economicdisadvantage.value += 1;
							break;	
						default:
							// no section, so count the card
							break;
					}; 
				}
			
			}); 
			
			if(flagObjects.economicdisadvantage.networth>0 || flagObjects.economicdisadvantage.adjustedgrossincome>0 || flagObjects.economicdisadvantage.assets>0)
			{
				if(flagObjects.economicdisadvantage.value == 0)
				{
					flagObjects.economicdisadvantage.value += 1;
				}
			}

		}
		catch { }
		
		//debugger
		try
		{
			showHideSections(executionContext, "WebResource_section_ownership_incomplete", "WebResource_ownership_section_label", flagObjects.ownership.value > 0);			
				showHideSections(executionContext, "WebResource_section_womenownership_incomplete", "WebResource_subsectin_womenownership", flagObjects.ownership.womenownership > 0);			
				showHideSections(executionContext, "WebResource_section_firmownership_incomplete", "WebResource_firmownershiplabel", flagObjects.ownership.firmownership > 0);			
				showHideSections(executionContext, "WebResource_subsection_businesstructure_incomplete", "WebResource_businessstructurelabel", flagObjects.ownership.businessstructure.value > 0);

			showHideSections(executionContext, "WebResource_section_othercerts_incomplete", "WebResource_othercertificationsection", flagObjects.othercertifications.value > 0);			
				showHideSections(executionContext, "WebResource_section_thirdparty_incomplete", "WebResource_thirdpartylabel", flagObjects.othercertifications.thirdparty > 0);			
				showHideSections(executionContext, "WebResource_section_cve_incomplete", "WebResource_cvelabel", flagObjects.othercertifications.cve > 0);			

			showHideSections(executionContext, "WebResource_section_control_incomplete", "WebResource_controllabel", flagObjects.control.value > 0);			
				showHideSections(executionContext, "WebResource_section_highestposition_incomplete", "WebResource_highestpositionlabel", flagObjects.control.highestposition > 0);			
				showHideSections(executionContext, "WebResource_section_fullcontrol_incomplete", "WebResource_fullcontrollabel", flagObjects.control.fullcontrol > 0);			
			
			showHideSections(executionContext, "WebResource_section_individcontrib_incomplete", "WebResource_individualcontributorssection", flagObjects.individualcontributor.value > 0);	
				showHideSections(executionContext, "WebResource_section_financialdata_incomplete", "WebResource_financiallabel", flagObjects.individualcontributor.financialdata > 0);			
			
			showHideSections(executionContext, "WebResource_section_economicdis_incomplete", "WebResource_economicdisadvantagelabel", flagObjects.economicdisadvantage.value > 0);			
				showHideSections(executionContext, "WebResource_section_networth_incomplete", "WebResource_subsection_networth", flagObjects.economicdisadvantage.networth > 0);			
				showHideSections(executionContext, "WebResource_section_adjustedgrossincome_incomplete", "WebResource_adjustedgrossincomelabel", flagObjects.economicdisadvantage.adjustedgrossincome > 0);			
				showHideSections(executionContext, "WebResource_section_assets_incomplete", "WebResource_assetslabel", flagObjects.economicdisadvantage.assets > 0);			
		}
		catch {}
	}
	
	processConditionalQuestions = function(executionContext) {
		try
		{
			var formContext = executionContext.getFormContext();
			var isWosbCertified = false;
			var wosbCertified = null;
			var isHeldByTrust = false;
			var heldByTrust= null;
			var hasTechnicalExpertise = true;
			var technicalExpertise = null;

			var userHasSupervisorRole = userHasRole(executionContext, "Insight.certify.WOSB.SupervisorAnalyst");
			var userHasPDReviewerRole = userHasRole(executionContext, "Insight.certify.WOSB.PDReviewer");
			var activeStage = formContext.data.process.getActiveStage().getName();
			
			wosbCertified = formContext.getAttribute("sbagcbd_iscertifieaswosbedwosb").getText();
			if(wosbCertified != null && wosbCertified.toLowerCase === "yes") {
				isWosbCertified = true;
			} 


			heldByTrust = formContext.getAttribute("sbagcbd_is51pownershipheldtrust").getText();
			if(heldByTrust != null && heldByTrust.toLowerCase === "yes") {
				isHeldByTrust = true;
			}

			
			hasTechnicalExpertise = formContext.getAttribute("sbagcbd_havetechnicalexpertise").getText();
			if(hasTechnicalExpertise != null && hasTechnicalExpertise.toLowerCase === "no") {
				hasTechnicalExpertise = false;
			}
			
			if(userHasPDReviewerRole || userHasSupervisorRole) {
				var tab_AnalystReview =  formContext.ui.tabs.get("tab_AnalystReview");
				var tab_SupervisorReview =  formContext.ui.tabs.get("tab_SupervisorReview");
				var tab_AppReviewSummary = formContext.ui.tabs.get("tab_AppReviewSummary");
				tab_AnalystReview.setVisible(false);
				tab_AppReviewSummary.setVisible(false);
				tab_SupervisorReview.setVisible(true);				
			}
			
			// hide SBA Notes if Active Stage - Final Approval
			var tab_SBANotes = formContext.ui.tabs.get("tab_SBANotes");			
			tab_SBANotes.setVisible(activeStage.toLowerCase() != "final approval");


			// Long Form tab
			//formContext.getControl("WebResource_question_sincereceiving").setVisible(isWosbCertified);
			//formContext.getControl("WebResource_question_trust_revocable").setVisible(isHeldByTrust);
			//formContext.getControl("WebResource_question_apphas_ultimate").setVisible(hasTechnicalExpertise);

			// SBA Notes tab
			formContext.getControl("WebResource_question_changesincircumstances").setVisible(isWosbCertified);
			formContext.getControl("WebResource_question_trustrevocable").setVisible(isHeldByTrust);
			formContext.getControl("WebResource_question_supervisorycontrol").setVisible(hasTechnicalExpertise);

			// both tabs
			formContext.getControl("sbagcbd_thirdpcertificationchanges").setVisible(isWosbCertified);

			formContext.getControl("sbagcbd_trustrevocabledesignateapp").setVisible(isHeldByTrust);
			formContext.getControl("sbagcbd_trustrevocabledesignateappnote").setVisible(isHeldByTrust);
			
			formContext.getControl("sbagcbd_supervisorycontrolicenses").setVisible(hasTechnicalExpertise);
		}
		catch
		{
		}
	}

	processAlerts = function(executionContext) {
		try
		{
			var formContext = executionContext.getFormContext();
			var section_ownership = true;

			var myUniqueId = "_myUniqueId";
			var wosb = formContext.getAttribute("sbagcbd_ownedbyanotherentity").getText();
			var message = "";

			if(wosb != "Yes")
			{
				message = "Application not valid - firm not at least 51% owned by women";
				formContext.ui.setFormNotification(message, "ERROR", myUniqueId);
				
				formContext.getControl("WebResource_section_ownership_error").setVisible(true);
				formContext.getControl("WebResource_summarysnapshot_ownership").setVisible(false);
				formContext.getControl("WebResource_ownership_section_label").setVisible(false);
				formContext.getControl("WebResource_section_ownership_incomplete").setVisible(false);
				
				formContext.getControl("WebResource_section_womenownership_error").setVisible(true);
				formContext.getControl("WebResource_ownership_section_label").setV(false);
			}
			else
			{
				showHideSections(executionContext, "WebResource_ownership_section_label", "WebResource_section_ownership_incomplete", section_ownership);
			}
		}
		catch
		{
		}
	 }
	
}).call(Sdk);