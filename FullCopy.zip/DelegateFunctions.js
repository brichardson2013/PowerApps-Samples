function openDelegatePage() {
    try {
        Xrm.Utility.showProgressIndicator("Adding Delegate to Group");
		//var dialogUrl = "https://apps.gov.powerapps.us/webplayer/iframeapp?hideNavBar=true&source=website&appId=/providers/Microsoft.PowerApps/apps/3c89fd8a-7f68-4667-aa15-41ebf2208961";
        //var dialogUrl = "https://apps.gov.powerapps.us/play/8f33223a-d5ae-4881-8224-17eff6454c9e?tenantId=3c89fd8a-7f68-4667-aa15-41ebf2208961";
		var dialogUrl = "/WebResources/sbagcbd_DelegationDialog.html";
        Xrm.Utility.closeProgressIndicator();
        var memberIdWindow = window.open(dialogUrl, "Assign Delegate", "scrollbars=no,resizable=no,menubar=no,status=no,toolbar=no,location=no,top=10,left=400,height=350,width=400");
		// memberIdWindow.addEventListener("beforeunload", function (event) {
			// window.close();
		// });
    } catch (e) {
        Xrm.Utility.closeProgressIndicator();
        console.log("OpenDelegatePage > catch > error: " + e.message);
    }
}

function isSupervisorRole() {
	var currentUserRoles = Xrm.Utility.getGlobalContext().userSettings.roles;
	currentUserRoles.forEach(function(currentRole) {
		if(currentRole.name.toLowerCase() == 'insight.certify.wosb.supervisoranalyst' || currentRole.name == 'system administrator')
		{
			return true;
		}
	});
	return false;
}

function loadDialog() {
	var windowURL = "";
	var dialogWindow = window.open(windowURL, "Assign Delegate", "scrollbars=no,resizable=yes,menubar=no,status=no,toolbar=no,top=10,left=400,height=700,width=500");
	dialogWindow.addEventListener("beforeunload", function (event) {
		dialogWindow.close();
	});
}
