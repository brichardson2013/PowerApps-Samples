function ColorCards() {
    sectionArray = document.getElementsByTagName('section');
    sectionArray.forEach(function(section) {
        if(section.attributes['data-id'] == “basic_eligibility_section”)
        {
	    section.setAttribute('style', 'background-color:aquamarine;');
        }
    });
}