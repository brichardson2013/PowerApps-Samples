function OpenAccountSurvey(firstPrimaryItemId) {
   try {
        Xrm.Utility.showProgressIndicator("Opening Account Survey");
        var recordId = firstPrimaryItemId.replace("{","").replace("}","").toLowerCase();
        var accountSurveyUrl = "https://web.powerapps.com/webplayer/iframeapp?hideNavBar=true&source=website&appId=/providers/Microsoft.PowerApps/apps/e24ce2b0-cea6-4115-a98c-ca3ac6333333&AccountId=" + recordId;
        Xrm.Utility.closeProgressIndicator();
        var memberIdWindow = window.open(accountSurveyUrl, "Account Survey", "scrollbars=yes,resizable=yes,height=950,width=950");
    } catch (e) {
        Xrm.Utility.closeProgressIndicator();
        console.log("OpenAccountSurvey > catch > error: " + e.message);
    }
}